<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});
Route::get('/order', function () {
    return view('order');
});
Route::get('/about', function () {
    return view('about');
});
// Route::post('/company/first_step', [App\Http\Controllers\PaymentController::class,'first_step'])->name('company.first_step');
// Route::post('/cf-submit-form', [App\Http\Controllers\PaymentController::class,'cfsubmitForm'])->name('firststep.form');
Route::controller(App\Http\Controllers\PaymentController::class)->group(function(){
    Route::post('users', 'store')->name('users.store');
});

