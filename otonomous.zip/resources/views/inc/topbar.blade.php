<header>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
            <a href="#" class="navbar-brand">Otonomous</a>
            <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarCollapse">
                <div class="navbar-nav" id="nav1">
                    <a href="#" class="nav-item nav-link">Book Free Call</a>
                    <a href="#" class="nav-item nav-link">About</a>
                </div>
                <div class="navbar-nav ms-auto" id="nav2">
                    <button href="#" class="nav-item nav-link btn btn-primary loginn" style="padding:5px 11px;color:white">Login</button>
                </div>
            </div>
        </div>
    </nav>
</header>
<div data-projection-id="1" style="opacity: 1;">
    <div class="login" style="display:none">
        <button class="login-modal-button" data-cy="login-modal-button" type="button" style="z-index: 10;">Close</button>
        <div class="login-modal">
            <div class="login-modal-content">
                <h2>Welcome to Otonomos</h2>
                <p>We use email auththentication with every login as a security measure. Your email will never be sold to a third party.</p>
                <form class="login-form"><input class="email-input" placeholder="Email Address" name="email" /><input class="login-button" type="submit" value="Login" /></form>
            </div>
        </div>
    </div>
</div>