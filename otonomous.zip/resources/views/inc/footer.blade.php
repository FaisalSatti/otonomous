<?php $segments = explode('/', $_SERVER['REQUEST_URI']);?>
@if($segments[1]!='order')
<div class="homepage-cart">
    <hr />
    <div class="cart-title">
        <span>
            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path
                    d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                    stroke="#C7D2FE"
                    stroke-width="1.5"
                    stroke-linecap="round"
                    stroke-linejoin="round"
                ></path>
            </svg>
        </span>
        <p class="title-text">YOUR CART</p>
    </div>
    <button class="cart-title-mobile" data-cy="mobile-cart-button" type="button" aria-label="close cart" style="margin: 1rem 0px 0px;">
        <div class="cart-title-mobile-row">
            <div class="cart-title-mobile-row-left" data-cy="cypress-cart-modal-open">
                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path
                        d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                        stroke="#C7D2FE"
                        stroke-width="1.5"
                        stroke-linecap="round"
                        stroke-linejoin="round"
                    ></path>
                </svg>
                <p>YOUR CART</p>
            </div>
            <p class="mobile-total">US$ 10,735.00</p>
        </div>
    </button>
    <div class="mobile-display">
        <div class="cart-scroll" data-cy="cart-scroller">
            <div>
                <div class="cart-product" data-cy="cart-product-0">
                    <div class="product-title">
                        <button data-cy="cart-product-item-0" class="product-title-link" type="button">BVI Limited Company</button>
                        <button type="button" data-testid="product-remove-from-cart" data-cy="product-remove-from-cart-0" aria-label="remove item from cart">
                            <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M0.575791 0.575821C0.810105 0.341507 1.19 0.341507 1.42432 0.575821L4.00006 3.15156L6.57579 0.575821C6.81011 0.341507 7.19 0.341507 7.42432 0.575821C7.65863 0.810136 7.65863 1.19003 7.42432 1.42435L4.84858 4.00009L7.42432 6.57582C7.65863 6.81014 7.65863 7.19004 7.42432 7.42435C7.19 7.65866 6.81011 7.65866 6.57579 7.42435L4.00006 4.84861L1.42432 7.42435C1.19 7.65866 0.810105 7.65866 0.575791 7.42435C0.341476 7.19004 0.341476 6.81014 0.575791 6.57582L3.15153 4.00009L0.575791 1.42435C0.341476 1.19003 0.341476 0.810136 0.575791 0.575821Z"
                                    fill="white"
                                ></path>
                            </svg>
                        </button>
                    </div>
                    <div class="cart-total">
                        <p style="margin-left: 1rem;">Total:</p>
                        <p style="text-align: right; margin-right: 0.5rem;">
                            US$ 3,905.00
                            <span>
                                <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 1rem;">
                                    <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </span>
                        </p>
                    </div>
                    <div style="opacity: 1; height: auto;">
                        <div class="cart-section">
                            <h5 class="cart-section-title">Required Services</h5>
                            <div class="cart-section-row">
                                <p>One-time required</p>
                                <p style="margin-right: 0.5rem;">1,595.00</p>
                            </div>
                            <div class="cart-section-row">
                                <p>Annually required</p>
                                <p style="margin-right: 0.5rem;">2,310.00</p>
                            </div>
                        </div>
                        <div class="cart-section">
                            <h5 class="cart-addons-title">Add-ons</h5>
                            <div class="cart-section-row">
                                <p>One-time Add-on</p>
                                <p style="margin-right: 0.5rem;">0.00</p>
                            </div>
                            <div class="cart-section-row">
                                <p>Annual Add-on</p>
                                <p style="margin-right: 0.5rem;">0.00</p>
                            </div>
                        </div>
                    </div>
                    <hr class="product-brake" style="margin-top: 0.75rem;" />
                </div>
            </div>
            <div>
                <div class="cart-product" data-cy="cart-product-1">
                    <div class="product-title">
                        <button data-cy="cart-product-item-1" class="product-title-link" type="button">Bahamas IBC</button>
                        <button type="button" data-testid="product-remove-from-cart" data-cy="product-remove-from-cart-1" aria-label="remove item from cart">
                            <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    fill-rule="evenodd"
                                    clip-rule="evenodd"
                                    d="M0.575791 0.575821C0.810105 0.341507 1.19 0.341507 1.42432 0.575821L4.00006 3.15156L6.57579 0.575821C6.81011 0.341507 7.19 0.341507 7.42432 0.575821C7.65863 0.810136 7.65863 1.19003 7.42432 1.42435L4.84858 4.00009L7.42432 6.57582C7.65863 6.81014 7.65863 7.19004 7.42432 7.42435C7.19 7.65866 6.81011 7.65866 6.57579 7.42435L4.00006 4.84861L1.42432 7.42435C1.19 7.65866 0.810105 7.65866 0.575791 7.42435C0.341476 7.19004 0.341476 6.81014 0.575791 6.57582L3.15153 4.00009L0.575791 1.42435C0.341476 1.19003 0.341476 0.810136 0.575791 0.575821Z"
                                    fill="white"
                                ></path>
                            </svg>
                        </button>
                    </div>
                    <div class="cart-total">
                        <p style="margin-left: 1rem;">Total:</p>
                        <p style="text-align: right; margin-right: 0.5rem;">
                            US$ 6,830.00
                            <span>
                                <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 1rem; transform: rotate(270deg);">
                                    <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </span>
                        </p>
                    </div>
                    <hr class="product-brake" style="margin-top: 0.125rem;" />
                </div>
            </div>
        </div>
        <div class="cart-section cart-bottom">
            <div class="cart-total">
                <p>Cart Total</p>
                <p style="margin-right: 0.5rem;">US$ 10,735.00</p>
            </div>
            <button type="button" aria-label="checkout button" class="checkout">Checkout</button>
        </div>
    </div>
</div>
<script>
    $(".mobile-display").slideToggle();
</script>
@endif
    

<div class="footer">
    <div class="footer-top">
        <div class="footer-left footer-section">
            <div class="logo-link"><a href="/"><img
                        src="data:image/gif;base64,R0lGODlhvAJiAIABAP///////yH/C1hNUCBEYXRhWE1QPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS4wLWMwNjEgNjQuMTQwOTQ5LCAyMDEwLzEyLzA3LTEwOjU3OjAxICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M1LjEgTWFjaW50b3NoIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjI3RDNEM0QzNzE5RjExRTRBRkU4OUE5MjU4MUQwMkQ2IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjI3RDNEM0Q0NzE5RjExRTRBRkU4OUE5MjU4MUQwMkQ2Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MjdEM0QzRDE3MTlGMTFFNEFGRTg5QTkyNTgxRDAyRDYiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MjdEM0QzRDI3MTlGMTFFNEFGRTg5QTkyNTgxRDAyRDYiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4B//79/Pv6+fj39vX08/Lx8O/u7ezr6uno5+bl5OPi4eDf3t3c29rZ2NfW1dTT0tHQz87NzMvKycjHxsXEw8LBwL++vby7urm4t7a1tLOysbCvrq2sq6qpqKempaSjoqGgn56dnJuamZiXlpWUk5KRkI+OjYyLiomIh4aFhIOCgYB/fn18e3p5eHd2dXRzcnFwb25tbGtqaWhnZmVkY2JhYF9eXVxbWllYV1ZVVFNSUVBPTk1MS0pJSEdGRURDQkFAPz49PDs6OTg3NjU0MzIxMC8uLSwrKikoJyYlJCMiISAfHh0cGxoZGBcWFRQTEhEQDw4NDAsKCQgHBgUEAwIBAAAh+QQBAAABACwAAAAAvAJiAAAC/4yPqcvtD6OctNqLs968+w+G4kiW5omm6sq27gvH8kzX9o3n+s73/g/kAIZEGHEYTCpBx6bzCT2uotSq9VpMYbfNGNQVNXLHL6vK3BqTc+qtrL02wefzE93NQqOu6bv+zGcXCOhXZVP4N4VoWLLoGEbySKWYOIKnJflEORiJRZjZNQOqmTfq1Gn6iJqaJegp97rH2gp7aWnbOEtbptunC3D7WxjcK4vLxGVc7BpLXOnM+ia8uYws7CdyDazMGRKXO83c7H2cfS39Sz1rrn3HHl47bi3/Xr1K7/ENHe0Fz71Orh2devb2Tbr3LGA6cd3mJXQIUMxCTP4+CByocCI4fP8d9Bk09Y8RwoPxCpbSGBIkwYvlhFQcSXJlTJijKHLs2DIjP4kmN0aEyLJhvpcfSdH8khLUp4c4hRbNhK6nT5VPg546qmrpTJlGGdZUh7RkWJupaKDUClWs1bFVh53c2vYtVbBSyF6Vq9TsT6BIDlCF1HTt3Q2AA3w1UNhiHcWJA4dCfLixYzUTsPHtCzlt5sGED5Zl2gA0Y8l42fqCy3WXS3erUWMQPblra4wOEI0mrZPza6e3cTO4ORQ21rq8eAcXOZv2buMUgMeWncFR7UXPoee23tx5Z+YIkk117dW3WvEavG+3vVz7A/NtMZeXHpp6cvDnhS/w2Jt+95zVsSf/9T8eedGxl55bF+BXAYHXmWaBJL/B9x5/9SGXoIL56beZfQ1a+B+A32F4IILZQVihhBFw2J+HJ2alAIsDmlggdw/CGCOF8akXIoofgngZgymqCIGDOeJ4o4w18lgkei26OKSRG+o4HY1NCgdlhFJeiORxTpZ45YzyPUmklxpyuaWYBibA5JQ2almmX1W+qN6bRwrYnnt00almlveRSOaYe4Y5IqBL8unml3C2KQFleeIJppFyLupjh4+VpmdljyZpGaRArtdloIiimWaGmR7qp6Wdirommzxe2miqkhJHKaN9Vjqokq3SCqqgpn6a65m1sjahq/PJ2quwP6oWpbHD/246nJ2x6rYgtJqy+iuxmEaqKrazwpGscsFqu6y0u+KaaJulTqsXucfaJe6c1P5pbbfMWhmvvIraK6K7yKbmrL7bhAerp5P+V4Oy7AYc4L89okGluvC2m1q0gu1L6sAJY9nvjtNmvDDFB0MMMML8enwrxM7xWi244ZIscGK2GoZysSp/C3KQ50Z184q6rmwxWjNX/DOnvOl4asr16pzzfrFA+K7R827MMdIG49B0uTvT/HS2RwsdM6q4IZiv1V3jG7SZjLBYdaFXc31z2GwULXXSQJetNd3jyg02h27bvDbZdst8dlZpe72131kT/jdPcl87dcc1S/x4yQ7n3dLebP83LnniansipOWMF2425kr3/WzkmWvur+l1Hx433nq/Dvfmorc8ORmdD+75trTmnu7YoTt8uuqrCy9235Tjw/vDs9+9POCG3G784J/HmzzOzbcOPNRR74i64cQ7T9rxXUs/PeujB4J27Iibz7eu1fdDevk9f8z+3N3LL3Lw84vvevy/17++UKQveurzXv6Kdz3FZe9/3+MZy7g3v+EdUHft4k8BA7g9B2aQeWEx1AVh5jsGRhB7ACzOAvGnMDAsjl73ax/oMJhC5akohCA8oQhjiLVdvIyGNMSfBpdwvhFGrGAvzOGdNkhBHMpwgrJr4PSOqESs3RA1CWQgFFcHxCD/OpGDQqQfEiH4RRZu0WlMlFkT3yc/L4bRhZHilggdp0a+wBBYGCtjDu0IxjU6To9JfCACt2YoMZbQgHxcooeAE78PovBVL7sjHlPnx5E9co+R1F8lUVjIORKwh+ADoIhQJD00stGGnRSSBC9JuyL2cZJ1HCMmM3nGeoVqlajkYvc+mZNQkm+KtfzjXBzZSxK20JKwtN8gDXnLppnSmF1kZjMv9wxcbpKTmiwmIQMpyGGSUZu+JOUovVnDaZ5rmZC05iujaEsG3auUWxTlNYP5zcNo0Jy8hGc57ak9em7Tk8qcZSqPuc9nvrNf69Siutx5TnQCE5vOxGdCTbhCWjoU/5nJLBo585lHVlLUOtIc3y4DKlBiNrKh+tyoRk9Z0nS6sp4KFSbrLirSjOKTf67SpSJBOlGTEoqkLc0mQP+5UmImzJVp86dKT3pUeoIylxe8KU57ytNRHQuqPkXqKa3HTZC20p4MhRojt6pQRIbQf1NkpK9+5DOrtrJ3P00jHOd5wohCM6Qu7Sls5BrOoM5VrUAdaX+edQhVGvOIRaFkW/PKVwoWtpv/5BdhS6ccPZG1rPCrYlVzusitqpGq8aTrxt4assTC8KtZNGlfRYvJylqWpKFFrVNxOtWUsnOir52tUidrW9mq0Ekf1alu64paif4WsbXDrUEL19unwpWzMf9d6HARilU8Jfe4We3mYTt7XeIid7qxrCg1q7ncoXr2qcxNanAh2jDjVrO84d2teguaT/Zal5/q1a5362vT90JXten9rn2ru1fBAve81L0vXgs8Ru6C17nPxZ2C4bsEyyn4v9l96Gm+C2HhynfAM63tgi+r19wWc7/k3TARaTRhEgsXvatlaXvrZM0U59e/FE6sikVsYrb298AIJrB5c3xPIL8ytg0u4IRr3GEPa/LFksQsixlV3yU/GcDY9XFuidxa2tIYyULmcpfrGVvxWvnCWdpyjUVhZgNuFqxmXeur9kjadb25tAGFFGB1HGJ3PbZjV4zWnfnsxSGm9cte+3P/Hwc93MaiucUBli2jOzsyRBP6v4aWc2uHF0daZjnRVeb0NTfd5Sh3N6eiVqSokYzSTS8U1D8Ws5Nb7V7/7lLJc8SyTIVMay8zGXJqlTGOfH1qMMeaxx+O6q2BDGyP0nrGxPayfG/cYzwmO83KHfajcbxrwyJbyQiFdrRj/OD3ebvY7zz2pDn86k6POcOnHbOz4Xrs5Z571O0Mdz+5LadpN9vCkB0vusGNbyMHXJzNdue42d3oPNP7mfq+9r/nnXB//zvbYE2yrJldcAcP/FPjfje6Xe1pYZPZ4Qt3aMe7vWyBp5zg4NR1kG8N62al++NTVnjJzXlyjFNZys4FOa6j/1zUUhPp1MHmJX93PtpUg/yqqg7z0qcaZ2dGfb4Q3+eiSQ7UPmt2zliUNGhdvTCvp0jsNbJ21TN3gwpf6yil28eT2b7n3LB4JWb3uRt/sO+K3x2KZ0ew2Xd66Uz321tX18zIDb+DogeZ8BmdOqjpyOqmb9avg5fq5CmPZwGjFPN697mkAd/kRB/55pw3q+XtftbAKl7Dpw99kYlOFNefffTrhfzh5fn40iuw5SA2qt6r3nHSp172wM+1s4f/edATv/WFp3a7fU/k4htfG6Z//Zapf/Rfop750eX94rn/+3jnHvm/l77QY5/8rsJY939H+vdtv37xbx/+vHa3y+fPeLu+Q7/84M+++9+/GLknf+ZGf/U3czyHf3vXfog3fvl3Ys7HegVogJ53eeRnWBTYgA5YgRa4fAr4NnnHYBo4gU+3gQHYZpJXfSJYgiaYfir4gP8Xgm1wewc4W5XngpBDdi3Igv6nfBm4elIUBNp3J7e3e+oXMpWmg8EXXwhHZ03ohE8IhVEohVNIhVVohVeIhVmohVvIhV3ohV8IhmEohmNIhmVohmeIhmmohmvIhm3ohm8Ih3Eoh3MYAQUAADs="
                        alt="The Otonomos logo"></a></div>
            <p class="footer-desc">Since 2015, Otonomos has helped doers and investors in crypto and tech more broadly
                assemble their entities in all relevant jurisdictions around the world.</p>
            <p class="footer-desc">Order an offchain entity à la carte and pay in crypto or fiat on <a
                    href="https://otonomos.com/">Otonomos</a>, or use the <a href="https://otoco.io/" target="_blank"
                    rel="noreferrer">OtoCo</a> onchain company assembly tool to spin up and manage your entity or DAO
                with your Ethereum wallet.</p>
        </div>
        <div class="footer-half-section">
            <h2 class="footer-title">Entities</h2>
            <a class="footer-link" href="/order/19/new">Bahamas IBC</a>
            <a class="footer-link" href="/order/1/new">BVI Limited Company</a>
            <a class="footer-link" href="/order/43/new">BVI Trust</a>
            <a class="footer-link" href="/order/2/new">Canada Limited Liability Partnership</a>
            <a class="footer-link" href="/order/47/new">Cayman Islands Web 3.0 Foundation</a>
            <a class="footer-link" href="/order/4/new">Cayman Islands Private Foundation</a>
            <a class="footer-link" href="/order/22/new">Cayman Islands ELC</a>
            <a class="footer-link" href="/order/5/new">Hong Kong Limited Company</a>
            <a class="footer-link" href="/order/49/new">Ireland Limited Company</a>
            <a class="footer-link" href="/order/50/new">Isle of Man Limited Company</a>
            <a class="footer-link" href="/order/58/new">Malta Limited Company</a>
        </div>
        
        <div class="footer-half-section">
            <h2 class="footer-title">Entities</h2>
            <a class="footer-link" href="/order/45/new">Marshall Islands LLC</a>
            <a class="footer-link" href="/order/24/new">Panama Foundation</a>
            <a class="footer-link" href="/order/27/new">Panama IBC</a>
            <a class="footer-link" href="/order/7/new">Singapore Limited Company</a>
            <a class="footer-link" href="/order/17/new">Switzerland Foundation</a>
            <a class="footer-link" href="/order/8/new">Switzerland GmbH (Zug)</a>
            <a class="footer-link" href="/order/56/new">UAE Freezone Company</a>
            <a class="footer-link" href="/order/9/new">UK Limited Liability Partnership</a>
            <a class="footer-link" href="/order/11/new">US - Delaware C-Corp</a>
            <a class="footer-link" href="/order/10/new">US - Delaware LLC</a>
            <a class="footer-link" href="/order/12/new">US - Wyoming LLC</a>
        </div>
            
        <div class="footer-half-section">
            <h2 class="footer-title">About Otonomos</h2><a href="https://otonomos.crisp.help/" target="_blank"
                class="footer-link" title="Otonomos Blog" rel="noreferrer">Helpdesk</a><a
                href="mailto:support@otonomos.com" class="footer-link" title="Email Support">support@otonomos.com</a><a
                href="https://newsletter.otonomos.com" target="_blank" class="footer-link" title="Otonomos Blog"
                rel="noreferrer">The Otonomist Blog</a><a class="footer-link" target="_blank" title="Terms and Privacy"
                href="/terms">Terms &amp; Privacy</a>
            <h2 class="footer-title" style="margin-top: 2rem;">Socials</h2><a class="footer-link" title="X"
                href="https://twitter.com/otonomos" target="_blank" rel="noreferrer">X</a><a class="footer-link"
                title="Medium" href="https://medium.com/@Otonomos/" target="_blank" rel="noreferrer">Medium</a><a
                class="footer-link" title="Telegram" href="https://t.me/joinchat/WA_QaO0e9NZiNGM1" target="_blank"
                rel="noreferrer">Telegram</a><a class="footer-link" title="Reddit"
                href="https://www.reddit.com/r/Otonomos/" target="_blank" rel="noreferrer">Reddit</a>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="footer-trademark">© Otonomos™ — All rights reserved</div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>


<script href="{{asset('assets/js/custom.js')}}"></script>
<script>

    $('.loginn').click(function(e){
        $('.login').css('display','');
    })
    $('.login-modal-button').click(function(e){
        $('.login').css('display','none');
    })
    $('.second_btn').click(pricing_second);
    $('.third_btn').click(pricing_third);
    $('.fourth_btn').click(pricing_fourth);
    $('.fifth_btn').click(pricing_fifth);
    $('.sixth_btn').click(pricing_sixth);
    $('.seventh_btn').click(pricing_seventh);
    $('.eighth_btn').click(pricing_eighth);
    $('.ninth_btn').click(pricing_ninth);
    $('.tenth_btn').click(pricing_tenth);
    $('.eleventh_btn').click(pricing_eleventh);
    
    $('.twelveth_btn').click(pricing_twelveth);
    $('.thirtieth_btn').click(pricing_thirtieth);
    $('.fourteenth_btn').click(pricing_fourteenth);
    $('.fifteenth_btn').click(pricing_fifteenth);
    $('.sixteenth_btn').click(pricing_sixteenth);
    $('.filter-display').change(filter_display_change);
    function pricing_second(){
        $('.all').css('display','none');
        $('.second').css('display','');
    }
    function pricing_third(){
        $('.all').css('display','none');
        $('.third').css('display','');
    }
    function pricing_fourth(){
        $('.all').css('display','none');
        $('.fourth').css('display','');
    }
    function pricing_fifth(){
        $('.all').css('display','none');
        $('.fifth').css('display','');
    }
    function pricing_sixth(){
        $('.all').css('display','none');
        $('.sixth').css('display','');
    }
    function pricing_seventh(){
        $('.all').css('display','none');
        $('.seventh').css('display','');
    }
    function pricing_eighth(){
        $('.all').css('display','none');
        $('.eighth').css('display','');
    }
    function pricing_ninth(){
        $('.all').css('display','none');
        $('.ninth').css('display','');
    }
    function pricing_tenth(){
        $('.all').css('display','none');
        $('.tenth').css('display','');
    }
    function pricing_eleventh(){
        $('.all').css('display','none');
        $('.eleventh').css('display','');
    }
    function pricing_twelveth(){
        $('.all').css('display','none');
        $('.twelveth').css('display','');
    }
    function pricing_thirtieth(){
        $('.all').css('display','none');
        $('.thirtieth').css('display','');
    }
    function pricing_fourteenth(){
        $('.all').css('display','none');
        $('.fourteenth').css('display','');
    }
    function pricing_fifteenth(){
        $('.all').css('display','none');
        $('.fifteenth').css('display','');
    }
    function pricing_sixteenth(){
        $('.all').css('display','none');
        $('.sixteenth').css('display','');
    }
    function filter_display_change(){
        $('.all').css('display','none');
        var this_class=$(this).find(":selected").attr('class');
        var get_class=this_class.split(' ');
        this_class=get_class[1];
        $('.'+this_class).trigger("click");
    }
    
    
    
    
    
    $(document).ready(laptopscreen);
    $(window).on('resize',laptopscreen);
    
    $(document).ready(mobilescreen);
    $(window).on('resize',mobilescreen);

    function laptopscreen() {
        if ( $(window).width() > 739) { 
            $('#nav2').removeClass('ms-auto');
            $('#nav1').addClass('ms-auto'); 
            $('#nav1').css('padding-right','90px');
            $('#nav2').css('padding-right','90px');
        }        
    }
    function mobilescreen() {
        if ( $(window).width() < 739) {
            // console.log("aa"); 
            // $('.filter-dropdown').append('<div class="dropdown"><button type="button" class="dropdown-option"><div><strong>all</strong><svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z" fill="#818CF8"></path></svg></div></button><button type="button" class="dropdown-option">Asset Protection</button><button type="button" class="dropdown-option">Banking</button><button type="button" class="dropdown-option">Crypto-Friendly</button><button type="button" class="dropdown-option">Digital Goods</button><button type="button" class="dropdown-option">Funds</button><button type="button" class="dropdown-option">Governance</button><button type="button" class="dropdown-option">holding</button><button type="button" class="dropdown-option">Investment Fund</button><button type="button" class="dropdown-option">OpCo</button><button type="button" class="dropdown-option">Privacy</button><button type="button" class="dropdown-option">Startup</button><button type="button" class="dropdown-option">Tax Optimized</button><button type="button" class="dropdown-option">Token Offering</button><button type="button" class="dropdown-option">Trading</button><button type="button" class="dropdown-option">VC Funding</button></div>')
        }        
        $('.order-container').find('hr').css('display','none');
        $('.clickopen').css('display','none');        
        $('.option-container').find('hr').css('display','none');
    }
    $('.order-package').click(function(e){
        var display=$(this).find('.clickopen').css('display')
        // console.log(display);
        if(display=='block'){
            console.log("aaaa");
            $(this).find('.clickopen').css('display','none');
            $(this).find('hr').css('display','none');
        }else{
            // console.log("bbbb");
            // console.log($(this).find('.clickopen').html());
            $(this).find('.clickopen').css('display','block');
            $(this).find('hr').css('display','block');
        }
    })
    $('.order-option').click(function(e){
        var display=$(this).find('.clickopen').css('display')
        // console.log(display);
        if(display=='block'){
            console.log("aaaa");
            $(this).find('.clickopen').css('display','none');
            $(this).find('hr').css('display','none');
        }else{
            // console.log("bbbb");
            // console.log($(this).find('.clickopen').html());
            $(this).find('.clickopen').css('display','block');
            $(this).find('hr').css('display','block');
        }
    });
    
    $('.amt_get').click(function(e){
        if($(this).find('path').attr('d')=="M14 9V14M14 14V19M14 14H19M14 14L9 14"){
            var amt1=$(this).find('path').attr("data-amount1");
            var amt2=$(this).find('path').attr("data-amount2")??0;
            var amt3=$(this).find('path').attr("data-amount3")??0;
            // var section_name=['Anonymizer','Prop','Token'];
            // for(var j=0;j<section_name.length;j++){
            //     $('.cart-section').find('.cart-addons-list[data-name='+section_name[j]+']').remove();
            // }

            var section_name=$(this).find('path').attr("data-name");
            
            $(this).find('path').attr('d','M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z');
            $(this).find('path').attr('transform','translate(9, 11)');
            var inputs = $(this).closest('div.order-option').html();
            console.log(inputs);
            var inputs2 = $(".option-title",inputs).html();
            var section_title=[];
            var a=1;
            var b='';
            $('.cart-section:nth-child(2)').find('h5').after('<div class="cart-addons-list" data-cy="cart-addons-list-0" data-name="'+section_name+'">');
            // for(var i = 0; i < inputs2.length; i++){
                // section_title.push($(inputs2[i]).text());
                var amt=$(this).find('path').attr("data-amount1")??0;
                var amts = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(amt);
                var amts = amts.replace(/[$]/g, '');
                $('.cart-section').find('.cart-addons-list[data-name='+section_name+']').append('<div class="cart-item cart-section-row" data-cy="cart-addon-product-0-addons-0"><button type="button" data-testid="remove-from-cart" aria-label="remove item from cart"><svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M0.575791 0.575821C0.810105 0.341507 1.19 0.341507 1.42432 0.575821L4.00006 3.15156L6.57579 0.575821C6.81011 0.341507 7.19 0.341507 7.42432 0.575821C7.65863 0.810136 7.65863 1.19003 7.42432 1.42435L4.84858 4.00009L7.42432 6.57582C7.65863 6.81014 7.65863 7.19004 7.42432 7.42435C7.19 7.65866 6.81011 7.65866 6.57579 7.42435L4.00006 4.84861L1.42432 7.42435C1.19 7.65866 0.810105 7.65866 0.575791 7.42435C0.341476 7.19004 0.341476 6.81014 0.575791 6.57582L3.15153 4.00009L0.575791 1.42435C0.341476 1.19003 0.341476 0.810136 0.575791 0.575821Z" fill="white"></path></svg></button><p class="cart-item-name">'+inputs2+'</p><p class="cart-item-price">'+amts+'</p></div>');
                a++;
            // }
            
            var one_time=$(this).find('path').attr("data-onetime")??0;
            var annual=$(this).find('path').attr("data-annual")??0;
            var total=$('.cart_total:first').text();
            
            total = total.replace(/[US$ ,]/g, '');
            total=parseFloat(total)+parseFloat(one_time)+parseFloat(annual);
            var total1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(total);
            total1 = total1.replace(/[$]/g, '');
            $('.cart_total').text('US$ '+total1)
            $('.mobile-total').text('US$ '+total1)
            // console.log(total);
            var onetime1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(one_time);
                var onetime1 = onetime1.replace(/[$]/g, '');
            $('#onetime_addon').text(onetime1);
            var annual1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(annual);
                var annual1 = annual1.replace(/[$]/g, '');
            $('#annual_addon').text(annual1);

            // $('.cart-section:first').find('h5').append('</div>');
        }else{
            // var items = $(".cart-section").find('.cart-addons-list').attr('data-name');
            // var section_name=$(this).find('path').attr("data-name");
            // if(items==section_name){
                // $('.cart-addons-list').each(function() {
                    var data_name=$(this).find('path').attr('data-name');
                    $(".cart-section").find('.cart-addons-list[data-name='+data_name+']').remove();
                // });
            
                    
                // if($(".cart-section").find('.cart-addons-list').attr('data-name')==items){
                //     $(".cart-section").find('.cart-addons-list[data-name='+items+']').remove();
                // }
            // }
                    
            
            $(this).find('path').attr('d','M14 9V14M14 14V19M14 14H19M14 14L9 14');
            $(this).find('path').attr('transform','translate(2, 2)');
            
            var one_time=$(this).find('path').attr("data-onetime")??0;
            var annual=$(this).find('path').attr("data-annual")??0;
            var annual_addon= $('#annual_addon').text();
            var onetime_addon=$('#onetime_addon').text();
            
            var total=$('.cart_total:first').text();
            total = total.replace(/[US$ ,]/g, '');
            total2=parseFloat(total)-parseFloat(annual)-parseFloat(one_time);
            
            var total1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(total2);
            total1 = total1.replace(/[$]/g, '');
            
            $('.mobile-total').text('US$ '+total1)
            $('.cart_total').text('US$ '+total1)
            annual_addon = annual_addon.replaceAll(',','');
            onetime_addon = onetime_addon.replaceAll(',','');
            var total_annual=parseFloat(annual_addon)-parseFloat(annual);
            var total_onetime=parseFloat(onetime_addon)-parseFloat(one_time);
            var onetime1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(total_onetime);
                var onetime1 = onetime1.replace(/[$]/g, '');
            $('#onetime_addon').text(onetime1);
            var annual1 = new Intl.NumberFormat(
                    'en-US', {
                    style: 'currency',
                    currency: 'USD',
                    currencyDisplay: 'narrowSymbol',
                        minimumFractionDigits: 2}).format(total_annual);
                var annual1 = annual1.replace(/[$]/g, '');
            $('#annual_addon').text(annual1);
        }
    })
    
    $('.checkout').click(function(e){
        var cart_total=$('.cart_total:first').text()
        $('.mobile-total').text(cart_total)
        $('.order-modal').modal('show');
    });
    // $('#firststep').on('submit',function(e){
    //     $('#firststep').css('display','none');
    //     $('#checkout_modal .modal-body').html(`<div class="payment-options">
    //         <button type="submit" class="stripe-link" data-cy="pay-with-stripe" aria-label="Pay with Stripe">
    //             Pay Using
    //             <span>
    //                 <svg viewBox="0 0 60 25" xmlns="http://www.w3.org/2000/svg" width="60" height="25" class="UserLogo variant--">
    //                     <title>Stripe logo</title>
    //                     <path
    //                         fill="var(--userLogoColor, #0A2540)"
    //                         d="M59.64 14.28h-8.06c.19 1.93 1.6 2.55 3.2 2.55 1.64 0 2.96-.37 4.05-.95v3.32a8.33 8.33 0 0 1-4.56 1.1c-4.01 0-6.83-2.5-6.83-7.48 0-4.19 2.39-7.52 6.3-7.52 3.92 0 5.96 3.28 5.96 7.5 0 .4-.04 1.26-.06 1.48zm-5.92-5.62c-1.03 0-2.17.73-2.17 2.58h4.25c0-1.85-1.07-2.58-2.08-2.58zM40.95 20.3c-1.44 0-2.32-.6-2.9-1.04l-.02 4.63-4.12.87V5.57h3.76l.08 1.02a4.7 4.7 0 0 1 3.23-1.29c2.9 0 5.62 2.6 5.62 7.4 0 5.23-2.7 7.6-5.65 7.6zM40 8.95c-.95 0-1.54.34-1.97.81l.02 6.12c.4.44.98.78 1.95.78 1.52 0 2.54-1.65 2.54-3.87 0-2.15-1.04-3.84-2.54-3.84zM28.24 5.57h4.13v14.44h-4.13V5.57zm0-4.7L32.37 0v3.36l-4.13.88V.88zm-4.32 9.35v9.79H19.8V5.57h3.7l.12 1.22c1-1.77 3.07-1.41 3.62-1.22v3.79c-.52-.17-2.29-.43-3.32.86zm-8.55 4.72c0 2.43 2.6 1.68 3.12 1.46v3.36c-.55.3-1.54.54-2.89.54a4.15 4.15 0 0 1-4.27-4.24l.01-13.17 4.02-.86v3.54h3.14V9.1h-3.13v5.85zm-4.91.7c0 2.97-2.31 4.66-5.73 4.66a11.2 11.2 0 0 1-4.46-.93v-3.93c1.38.75 3.1 1.31 4.46 1.31.92 0 1.53-.24 1.53-1C6.26 13.77 0 14.51 0 9.95 0 7.04 2.28 5.3 5.62 5.3c1.36 0 2.72.2 4.09.75v3.88a9.23 9.23 0 0 0-4.1-1.06c-.86 0-1.44.25-1.44.9 0 1.85 6.29.97 6.29 5.88z"
    //                         fill-rule="evenodd"
    //                     ></path>
    //                 </svg>
    //             </span>
    //         </button>
    //         <button type="button" class="bankwire" aria-label="Pay with Wire Transfer">Pay Using<span>Wire Transfer</span></button>
    //         <svg width="64px" height="64px" viewBox="0 0 128 128" xml:space="preserve" style="display: none;">
    //             <rect x="0" y="0" width="100%" height="100%" fill="none"></rect>
    //             <path fill="#ffffff" id="ball1" class="cls-1" d="M67.712,108.82a10.121,10.121,0,1,1-1.26,14.258A10.121,10.121,0,0,1,67.712,108.82Z">
    //                 <animateTransform
    //                     attributeName="transform"
    //                     type="rotate"
    //                     values="0 64 64;4 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;"
    //                     dur="1200ms"
    //                     repeatCount="indefinite"
    //                 ></animateTransform>
    //             </path>
    //             <path fill="#ffffff" id="ball2" class="cls-1" d="M51.864,106.715a10.125,10.125,0,1,1-8.031,11.855A10.125,10.125,0,0,1,51.864,106.715Z">
    //                 <animateTransform
    //                     attributeName="transform"
    //                     type="rotate"
    //                     values="0 64 64;10 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;"
    //                     dur="1200ms"
    //                     repeatCount="indefinite"
    //                 ></animateTransform>
    //             </path>
    //             <path fill="#ffffff" id="ball3" class="cls-1" d="M33.649,97.646a10.121,10.121,0,1,1-11.872,8A10.121,10.121,0,0,1,33.649,97.646Z">
    //                 <animateTransform
    //                     attributeName="transform"
    //                     type="rotate"
    //                     values="0 64 64;20 64 64;40 64 64;65 64 64;85 64 64;100 64 64;120 64 64;140 64 64;160 64 64;185 64 64;215 64 64;255 64 64;300 64 64;"
    //                     dur="1200ms"
    //                     repeatCount="indefinite"
    //                 ></animateTransform>
    //             </path>
    //         </svg>
    //         </div>`);
    // })
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $('.submit-info').click(function(e) {
        e.preventDefault();

        // Serialize the form data
        var name = $("#username").val();
        var email = $("#email").val();
        // Send an AJAX request
        $.ajax({
            type: 'POST',
            url:"{{ route('users.store') }}",
            data:{name:name, email:email},
            success: function(response) {
                $(".cart-section").each(function() {
                    console.log($(this).html());
                });

                $('#checkout_modal .modal-body').html(`<div class="payment-options">
                    <button type="submit" class="stripe-link" data-cy="pay-with-stripe" aria-label="Pay with Stripe">
                        Pay Using
                        <span>
                            <svg viewBox="0 0 60 25" xmlns="http://www.w3.org/2000/svg" width="60" height="25" class="UserLogo variant--">
                                <title>Stripe logo</title>
                                <path
                                    fill="var(--userLogoColor, #0A2540)"
                                    d="M59.64 14.28h-8.06c.19 1.93 1.6 2.55 3.2 2.55 1.64 0 2.96-.37 4.05-.95v3.32a8.33 8.33 0 0 1-4.56 1.1c-4.01 0-6.83-2.5-6.83-7.48 0-4.19 2.39-7.52 6.3-7.52 3.92 0 5.96 3.28 5.96 7.5 0 .4-.04 1.26-.06 1.48zm-5.92-5.62c-1.03 0-2.17.73-2.17 2.58h4.25c0-1.85-1.07-2.58-2.08-2.58zM40.95 20.3c-1.44 0-2.32-.6-2.9-1.04l-.02 4.63-4.12.87V5.57h3.76l.08 1.02a4.7 4.7 0 0 1 3.23-1.29c2.9 0 5.62 2.6 5.62 7.4 0 5.23-2.7 7.6-5.65 7.6zM40 8.95c-.95 0-1.54.34-1.97.81l.02 6.12c.4.44.98.78 1.95.78 1.52 0 2.54-1.65 2.54-3.87 0-2.15-1.04-3.84-2.54-3.84zM28.24 5.57h4.13v14.44h-4.13V5.57zm0-4.7L32.37 0v3.36l-4.13.88V.88zm-4.32 9.35v9.79H19.8V5.57h3.7l.12 1.22c1-1.77 3.07-1.41 3.62-1.22v3.79c-.52-.17-2.29-.43-3.32.86zm-8.55 4.72c0 2.43 2.6 1.68 3.12 1.46v3.36c-.55.3-1.54.54-2.89.54a4.15 4.15 0 0 1-4.27-4.24l.01-13.17 4.02-.86v3.54h3.14V9.1h-3.13v5.85zm-4.91.7c0 2.97-2.31 4.66-5.73 4.66a11.2 11.2 0 0 1-4.46-.93v-3.93c1.38.75 3.1 1.31 4.46 1.31.92 0 1.53-.24 1.53-1C6.26 13.77 0 14.51 0 9.95 0 7.04 2.28 5.3 5.62 5.3c1.36 0 2.72.2 4.09.75v3.88a9.23 9.23 0 0 0-4.1-1.06c-.86 0-1.44.25-1.44.9 0 1.85 6.29.97 6.29 5.88z"
                                    fill-rule="evenodd"
                                ></path>
                            </svg>
                        </span>
                    </button>
                    <button type="button" class="bankwire" aria-label="Pay with Wire Transfer">Pay Using<span>Wire Transfer</span></button>
                    <svg width="64px" height="64px" viewBox="0 0 128 128" xml:space="preserve" style="display: none;">
                        <rect x="0" y="0" width="100%" height="100%" fill="none"></rect>
                        <path fill="#ffffff" id="ball1" class="cls-1" d="M67.712,108.82a10.121,10.121,0,1,1-1.26,14.258A10.121,10.121,0,0,1,67.712,108.82Z">
                            <animateTransform
                                attributeName="transform"
                                type="rotate"
                                values="0 64 64;4 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;"
                                dur="1200ms"
                                repeatCount="indefinite"
                            ></animateTransform>
                        </path>
                        <path fill="#ffffff" id="ball2" class="cls-1" d="M51.864,106.715a10.125,10.125,0,1,1-8.031,11.855A10.125,10.125,0,0,1,51.864,106.715Z">
                            <animateTransform
                                attributeName="transform"
                                type="rotate"
                                values="0 64 64;10 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;0 64 64;"
                                dur="1200ms"
                                repeatCount="indefinite"
                            ></animateTransform>
                        </path>
                        <path fill="#ffffff" id="ball3" class="cls-1" d="M33.649,97.646a10.121,10.121,0,1,1-11.872,8A10.121,10.121,0,0,1,33.649,97.646Z">
                            <animateTransform
                                attributeName="transform"
                                type="rotate"
                                values="0 64 64;20 64 64;40 64 64;65 64 64;85 64 64;100 64 64;120 64 64;140 64 64;160 64 64;185 64 64;215 64 64;255 64 64;300 64 64;"
                                dur="1200ms"
                                repeatCount="indefinite"
                            ></animateTransform>
                        </path>
                    </svg>
                    </div>`);
            
                // $('.message').text('response.text')
            },
            error: function(xhr, status, error) {
                // Handle errors if needed
                console.error(xhr.responseText);
            }
        });
    });
        
    // $('body').click(function (event) 
    // {
    //     if(!$(event.target).closest('#openModal').length && !$(event.target).is('#openModal')) {
    //         $(".modalDialog").hide();
    //     }     
    // });
    // window.onclick = function(event) {
    //     if (event.target.className != "order-modal" && event.target.className != "checkout") {
    //        console.log(event.target.className);
    //     $('.order-modal').css('display','none');
    //    }
    // }
    $('.homepage-cart').click(function(e){
        $(".mobile-display").slideToggle();
    }) 
        


</script>