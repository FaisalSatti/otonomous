@include('inc.header')
<body>
    @include('inc.topbar')
    @yield('content')
    
    @include('inc.footer')
</body>
</html>
