<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use App\Models\User;
class PaymentController extends Controller
{
    // public function first_step( Request $request ) {
    //     var_dump($request);
    //     // $validator = Validator::make( $request->all(), [
    //     // 'username' => 'required|string|max:255',
    //     // ],
    //     // [
        
    //     // 'username.required' => 'Please Enter Username'
    //     // ],[
    //     // 'email' => 'required|string|max:255',
    //     // ],
    //     // [
        
    //     // 'email.required' => 'Please Enter Email'
    //     // ] );
        
    //     // if ( $validator->fails() ) {
    //     //     return response()->json( [ 'errors' => $validator->errors() ] );
    //     // }
        
    //     // $user = new User( [
    //     // 'name' => $request->input( 'username' ),
    //     // 'email' => $request->input( 'email' ),
        
    //     // ] );
    //     // $user->save();
    //     return response()->json( [ 'success' => 'Customer registered successfully!' ] );
    // }
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required',
        ]);
  
        if ($validator->fails()) {
            return response()->json([
                'error' => $validator->errors()->all()
            ]);
        }
       
        User::create([
            'name' => $request->name,
            'email' => $request->email,
        ]);
  
        return response()->json(['success' => 'User created successfully.']);
    }
}
