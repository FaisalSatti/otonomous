
<?php $__env->startSection('content'); ?>
<style>
    body{background-color:#111827}
    .cart, .homepage-cart{position:inherit;margin:0px 0 -0.2rem}
    .call-to-action-container{margin:4rem .5rem 2rem}
</style>
<div class="about">
    <div class="motion">
        <div class="landing-container">
            <div class="hero" style="z-index: 2; height: 14rem;"></div>
            <div class="title-container">
                <h5>From the Founder</h5>
                <h2>Why am I doing <span>Otonomos?</span>
                </h2>
            </div>
            <div class="info-container">
                <div class="info-text-box">
                    <p>Not every generation has the privilege of seeing a whole new paradigm being built right in front of its eyes.</p>
                    <p>Gates and Jobs perhaps with the birth of the personal computer, or the generation before them with the advent of the silicon wafer.</p>
                    <p>A century earlier, it was the generation that saw the wider adoption of the steam engine, itself an invention that dates back to the 18th Century.</p>
                    <p>In our century, it is us, with the birth of “crypto”.</p>
                    <p>I myself feel incredibly lucky to be alive today, and to have happened to be there in the early days of Ethereum.</p>
                    <p>Now almost a decade later, more than at any time I believe crypto lets us imagine and experiment with a different, more decentralized and ultimately fairer future.</p>
                    <p>
                        Otonomos is the way I felt I could contribute. It's where for me it all comes together: the community's ethos of self-reliance through sharing, the knowledge I gained from the things I did before, my belief that we can achieve
                        autonomy and freedom if we work at it hard enough.
                    </p>
                    <p>Every day, I get to see our clients, each in their own way, make a dent in the universe. In return for us helping them in our own way, we get a front seat on a whole new tomorrow. That's why Otonomos keeps me fulfilled.</p>
                    <p>- Han, Founder &amp; CEO</p>
                    <img src="<?php echo e(asset('assets/imgs/Team.jpg')); ?>" alt="Otonomos' vancouver team" />
                </div>
            </div>
        </div>
        <div class="person-display">
            <div class="person-title-container">
                <h5>Core team</h5>
                <h2>Code x Law x Business</h2>
                <p>Our core team has seasoned business builders, technology talent and domain experts in equal measure.</p>
            </div>
            <div class="motion" data-projection-id="63" style="opacity: 1;">
                <h3>Business</h3>
                <div class="person-display-container">
                    <div data-projection-id="64" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Han Verstraete's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/L7sr68Bz0RFFWFEf.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Founder &amp; CEO</div>
                                        <strong>Han Verstraete</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Founder and CEO, came out of TradFin early 2000’s, exited two businesses in UK, stood at cradle of Ethereum and built Otonomos into crypto’s homegrown entity assembler and corporate service provider.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="65" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Daan Corne's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/cnBVIwN667lphC7S.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Operations Manager</div>
                                        <strong>Daan Corne</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">Daan has a passion for business, investing and the crypto space. Working on business solutions is what he enjoys the most.</div>
                        </div>
                    </div>
                    <div data-projection-id="66" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Modita  Singh's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/eamf7KvStqUY12Tv.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Legal Compliance Manager</div>
                                        <strong>Modita Singh</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Modita is a legal professional who is passionate about blockchain and the new horizon it allows. With years of experience of working in the legal service industry, Modita assists in facilitating the incorporation of
                                companies in different parts of the world. In her leisure time, she likes to travel and spend time with my family and friends.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="67" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Alvin Magsino's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/s48XreflN90xFvf7.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Client Success Manager</div>
                                        <strong>Alvin Magsino</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">Alvin is our dedicated go-to person for all your entity related questions. If you need a certificate of Incumbency, certified documents or change your director, Alvin can help.</div>
                        </div>
                    </div>
                    <div data-projection-id="68" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Fernanda Garcia's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/QD9LhzWujutJrJwG.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Finance Manager</div>
                                        <strong>Fernanda Garcia</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Fernanda is a Finance Manager at Otonomos, with her experience in the field and working closely with our sales team she will be happy to optimize your resources in terms of money. She takes the time to keep herself
                                updated. She is a dog lover!
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="69" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Stuart Platt-Ransom's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/aqJ691GQJm05dd8P.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">COO</div>
                                        <strong>Stuart Platt-Ransom</strong>
                                        <p>London, United Kingdom</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Stuart is an experienced executive with 25+ years in the financial services sector. He has held leadership positions across the UK, Europe, Africa, and the Middle East. Notably, he served as CEO of the Oak Group and
                                led a successful management buyout as chairman and CEO of the Legis Group
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="70" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(99, 102, 241);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Simon Lang's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/IS0fBNw11kUqjWmd.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">CRM Manager</div>
                                        <strong>Simon Lang</strong>
                                        <p>London, United Kingdom</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Simon’s background is CRM and sales enablement for Bentley Motors and Swan Yachts, and building emerging markets including the Far East. He developed CRM projects with a leading software author, working with clients
                                such as Mitsubishi Chemical and Pinewood studios. Now attracted to the fast-developing Web3 space, he joined the Otonomos team.
                            </div>
                        </div>
                    </div>
                </div>
                <h3>Sales</h3>
                <div class="person-display-container">
                    <div data-projection-id="71" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(34, 211, 238);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Tyler Sinclair's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/BwnbuNHNf4NQRz3M.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Lead Manager</div>
                                        <strong>Tyler Sinclair</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Tyler is a blockchain enthusiast turned sales professional committed to delivering exceptional customer service. His experience using a variety of projects across multiple chains allows him to have the knowledge to
                                connect your project to the right jurisdiction for its needs. In his free time he is an avid gamer and hockey fan.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="72" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(34, 211, 238);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Anton Kouprianov's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/HPCXQ9bca4BleSuI.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Account Director</div>
                                        <strong>Anton Kouprianov</strong>
                                        <p>London, United Kingdom</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Passionate about tech and its commercial exploitation for the good of business and mankind. Drone pilot, basketball &amp; snowboarding enthusiast. 10 years with Salesforce &amp; Web2 tech before taking his talents to
                                Web3.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="73" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(34, 211, 238);">
                            <div class="card-top">
                                <div class="pic-border"><img alt=" 's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/OQhqrO9BHgTo3Pxn.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Business Development Executive</div>
                                        <strong> </strong>
                                        <p>London, United Kingdom</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Career in offshore financial services. Ran a successful global sales consultancy firm for 15 years before moving fully into the corporate service provider space and now into the exciting crypto industry.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="74" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(34, 211, 238);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Johan Gouws's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/SgWt5TPvDKdtmYHA.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Institutional Business Development</div>
                                        <strong>Johan Gouws</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Former private &amp; investment banker, Johan leverages his expertise to guide clients in establishing legal entities for global tax &amp; regulatory optimization, prioritising privacy. His services encompass startup
                                funds, tokenized project and structures for holding, exiting and wealth management, assisting institutions in addressing their clients' global requirements.
                            </div>
                        </div>
                    </div>
                </div>
                <h3>Developers</h3>
                <div class="person-display-container">
                    <div data-projection-id="75" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(165, 180, 252);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Marcio Cruz's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/f1XSb6WVgyqcr0c8.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Full Stack Web Developer</div>
                                        <strong>Marcio Cruz</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                A logistics professional who transitioned to I.T. with a passion for data analisys. With a strong background in logistics and organizational skills, he excels in creating data-driven solutions that optimize
                                operations.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="76" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(165, 180, 252);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="James Pescosta's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/SrnM490Cq12RneMn.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Full Stack Web Developer</div>
                                        <strong>James Pescosta</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">James is the Aussie dev who spearheads our development sprints at Otonomos. He is the mind behind the Otonomos site and works on the ever increasing expansion of this website.</div>
                        </div>
                    </div>
                    <div data-projection-id="77" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(165, 180, 252);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Mikiya Ichino's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/6clZGRK9St8on3Hz.jpg" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Full Stack Developer</div>
                                        <strong>Mikiya Ichino</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Mikiya is a seasoned full-stack developer, specializing in backend processes. He has a diverse background, having developed core systems for real estate agencies and created mobile applications for IoT devices.
                                Currently, he's deeply interested in the growing areas of Web3 and blockchain technology.
                            </div>
                        </div>
                    </div>
                    <div data-projection-id="78" style="opacity: 1;">
                        <div class="person-card" data-testid="person-card" style="border: 1px solid rgb(165, 180, 252);">
                            <div class="card-top">
                                <div class="pic-border"><img alt="Jacob Allen's mugshot" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/employeePics/GXXBEc2okeQBV4U7.png" /></div>
                                <div class="person-info">
                                    <div class="person-name">
                                        <div class="person-title">Full Stack Developer</div>
                                        <strong>Jacob Allen</strong>
                                        <p>Vancouver, Canada</p>
                                    </div>
                                </div>
                            </div>
                            <div class="person-blurb">
                                Jacob, an Aussie Full-Stack Developer, has contributed to the development of core ecommerce applications for Pattison Food Group and has extensive experience in Technical Support for various other leading Canadian
                                retailers. Jacob is currently immersed in the dynamic and rapidly expanding realm of Web Development.
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="location-display">
            <div class="location-title-container">
                <h5>OFFICE DIRECTORY</h5>
                <h2>Basecamps in all major jurisdictions</h2>
                <p>Otonomos can cover clients who are global from day one</p>
            </div>
            <div class="motion" data-projection-id="79" style="opacity: 1;">
                <div class="location-display-container">
                    <div data-projection-id="80" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Bahamas</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Winterbotham Place, Marlborough &amp; Queen St, Nassau, New Providence 62556 - The Bahamas</div>
                        </div>
                    </div>
                    <div data-projection-id="81" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">British Virgin Islands</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Quijano Chambers, P.O. Box 3159, Road Town 3159 - British Virgin Islands</div>
                        </div>
                    </div>
                    <div data-projection-id="82" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Canada</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">1626 Duranleau Street, Vancouver, BC V6H 3S4 - Canada</div>
                        </div>
                    </div>
                    <div data-projection-id="83" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Cayman Islands</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">102, Cannon Place P.O. Box 712, Nth Sound Rd George Town, Gr. Cayman KY1-9006 - Cayman Islands</div>
                        </div>
                    </div>
                    <div data-projection-id="84" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Hong Kong</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Unit 03, 8/F Greenfield Tower Concordia Plaza No.1 Science Museum Road, Kowloon - Hong Kong</div>
                        </div>
                    </div>
                    <div data-projection-id="85" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Panama</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Bloc Office Hub, Fifth Floor, Santa Maria Business District, Panama City, Panamá 801 - Panama</div>
                        </div>
                    </div>
                    <div data-projection-id="86" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Singapore</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">183 Jalan Pelikat #B2-02 The Promenade @ Pelikat, Singapore, Central Singapore 537643 - Singapore</div>
                        </div>
                    </div>
                    <div data-projection-id="87" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">Switzerland</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Weinberghöhe 31 CH-6340 Baar - Switzerland</div>
                        </div>
                    </div>
                    <div data-projection-id="88" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">US - California</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">1401 21St St Ste R, Sacramento, California 95811 - United States</div>
                        </div>
                    </div>
                    <div data-projection-id="89" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">US - Delaware</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">8 The Green, Suite R, Dover, Delaware 19901 - United States</div>
                        </div>
                    </div>
                    <div data-projection-id="90" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">US - Miami</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">3350 Virginia Street, Coconut Grove, Miami, 33133 - United States</div>
                        </div>
                    </div>
                    <div data-projection-id="91" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">US - Wyoming</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">30 N Gould St Ste R, Sheridan, Wyoming 82801 - United States</div>
                        </div>
                    </div>
                    <div data-projection-id="92" style="opacity: 1;">
                        <div class="location-card" data-testid="location-card">
                            <div class="location-title">United Kingdom</div>
                            <div class="reg-address">Basecamp</div>
                            <div class="location-address">Dept 3580, 601 International House 223 Regent Street, Mayfair, London, United Kingdom, W1B 2QD</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="call-to-action-container">
            <h5>Where To Begin</h5>
            <h2>Assemble your gear today and start building from anywhere.</h2>
            <a class="call-to-action" href="<?php echo e(url('')); ?>">Get Started</a>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\otonomous\resources\views/about.blade.php ENDPATH**/ ?>