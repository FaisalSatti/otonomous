
<?php $__env->startSection('content'); ?>
<div class="order-page">
    <div class="order-page-content">
        <!-- <div class="order-modal" style="display:none">
            <div class="modal-background"></div>
            <div class="order-modal-content" style="opacity: 1;">
                <div class="modal-header">
                    <p>
                        <span>
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                                    stroke="#C7D2FE"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                        </span>
                        YOUR CART
                    </p>
                    <p class="mobile-total">US$ 10,735.00</p>
                </div>
                <p class="modal-desc">The following infomation is required to process your order.</p>
                <form class="customer-info-form">
                    <div class="info-question">
                        <label class="info-label">Choose a username you want to use:</label><br />
                        <input data-cy="cy-username-input" name="username" />
                    </div>
                    <div class="info-question">
                        <label class="info-label">What email address do you want to use:</label><br />
                        <input data-cy="cy-email-input" name="email" />
                    </div>
                    <div class="terms">By proceeding with your payment you agree to our <a target="_blank" rel="noopener noreferrer" href="/terms">T&amp;Cs</a></div>
                    <input aria-label="Submit form button" class="submit-info" type="submit" value="Proceed to Payment" />
                </form>
            </div>
        </div> -->
        <div class="modal order-modal" id="checkout_modal" tabindex="-1" role="dialog">
            <!-- <div class="modal-background"></div> -->
            <div class="modal-dialog order-modal-content" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <p>
                            <span>
                                <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path
                                        d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                                        stroke="#C7D2FE"
                                        stroke-width="1.5"
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                    ></path>
                                </svg>
                            </span>
                            YOUR CART
                        </p>
                        <p class="mobile-total">US$ 10,735.00</p>
                    </div>
                    <div class="modal-body">
                        <p class="message"></p>
                        <form class="customer-info-form" id="firststep">
                            <div class="info-question">
                                <label class="info-label">Choose a username you want to use:</label><br />
                                <input type="text"  name="username" id="username" required>
                            </div>
                            <div class="info-question">
                                <label class="info-label">What email address do you want to use:</label><br />
                                <input type="email"  name="email" id="email" required>
                            </div>
                            <div class="terms">By proceeding with your payment you agree to our <a target="_blank" rel="noopener noreferrer" href="/terms">T&amp;Cs</a></div>
                            <input aria-label="Submit form button" class="submit-info" type="submit" value="Proceed to Payment" />
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="hero" data-cy="order-page-hero"></div>
        <div style="opacity: 1;">
            <div class="order-page-left">
                <div class="title-container">
                    <h1>Bahamas IBC</h1>
                    <h2 class="title-subtext">For token distribution, banking and holding purposes.</h2>
                    <p>
                        Own an International Business Corporation in the Bahamas in 3 to 5 business days. Incorporate with model articles and appoint us as your local agent to activate your company. The Bahamas offer privacy and respectability,
                        with a modern set of crypto laws ideally suited for airdrops and free token distributions. Directors in Bahamas are a matter of public record but shareholders information is not visible. There are also good banking
                        options and the Bahamas are easily accessible.
                    </p>
                </div>
                <div class="required-container">
                    <h2>
                        <span>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M3 12C3 13.1819 3.23279 14.3522 3.68508 15.4442C4.13738 16.5361 4.80031 17.5282 5.63604 18.364C6.47177 19.1997 7.46392 19.8626 8.55585 20.3149C9.64778 20.7672 10.8181 21 12 21C13.1819 21 14.3522 20.7672 15.4442 20.3149C16.5361 19.8626 17.5282 19.1997 18.364 18.364C19.1997 17.5282 19.8626 16.5361 20.3149 15.4442C20.7672 14.3522 21 13.1819 21 12C21 10.8181 20.7672 9.64778 20.3149 8.55585C19.8626 7.46392 19.1997 6.47177 18.364 5.63604C17.5282 4.80031 16.5361 4.13738 15.4442 3.68508C14.3522 3.23279 13.1819 3 12 3C10.8181 3 9.64778 3.23279 8.55585 3.68508C7.46392 4.13738 6.47177 4.80031 5.63604 5.63604C4.80031 6.47177 4.13738 7.46392 3.68508 8.55585C3.23279 9.64778 3 10.8181 3 12Z"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M10.2 9.9019L15.9614 7.52952C16.0326 7.50011 16.1109 7.49246 16.1864 7.50753C16.262 7.5226 16.3314 7.55971 16.3858 7.61417C16.4403 7.66864 16.4774 7.73802 16.4925 7.81356C16.5075 7.8891 16.4999 7.96741 16.4705 8.03861L14.0981 13.8"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M13.8 14.0981L9.9019 10.2L7.52952 15.9614C7.50011 16.0326 7.49246 16.1109 7.50753 16.1864C7.5226 16.262 7.55971 16.3314 7.61417 16.3858C7.66864 16.4403 7.73802 16.4774 7.81356 16.4925C7.8891 16.5075 7.96741 16.4999 8.03861 16.4705L13.8 14.0981Z"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                        </span>
                        PACK THE MINIMUM TO SURVIVE
                    </h2>
                    <div class="order-package" data-cy="order-package-undefined">
                        <div type="button" aria-label="open/close package" class="order-container" data-testid="order-package" style="margin: 0px;">
                            <div class="package-top">
                                <div class="package-top-left">
                                    <div>
                                        <div class="package-title">Minimum Kit</div>
                                        <p class="package-desc">The essentials to start your journey</p>
                                    </div>
                                </div>
                                <div class="package-top-right">
                                    <p class="package-currency">US$</p>
                                    <p class="package-price">4,830.00</p>
                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                    </svg>
                                </div>
                            </div>
                            <hr>
                            <div style="opacity: 1; height: auto;" class="clickopen">
                                <div class="package-bottom">
                                    <div class="package-service">
                                        <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                fill="#818CF8"
                                            ></path>
                                        </svg>
                                        <p class="service-title">EIN Application</p>
                                        <div class="infotip">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                    stroke="#6B7280"
                                                    stroke-width="1.5"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                ></path>
                                            </svg>
                                        </div>
                                        <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                    </div>
                                    <div class="package-service">
                                        <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                fill="#818CF8"
                                            ></path>
                                        </svg>
                                        <p class="service-title">Incorporation</p>
                                        <div class="infotip">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                    stroke="#6B7280"
                                                    stroke-width="1.5"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                ></path>
                                            </svg>
                                        </div>
                                        <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                    </div>
                                    <div class="package-service">
                                        <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                fill="#818CF8"
                                            ></path>
                                        </svg>
                                        <p class="service-title">Registered Address &amp; Office</p>
                                        <div class="infotip">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                    stroke="#6B7280"
                                                    stroke-width="1.5"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                ></path>
                                            </svg>
                                        </div>
                                        <p class="service-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                    </div>
                                </div>
                            </div>
                                
                        </div>
                    </div>
                </div>
                <!-- <div class="package-container">
                    <h2>
                        <span>
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M19.4315 3H4.56845C3.70222 3 3 3.70222 3 4.56845V6.34064C3 7.20687 3.70222 7.90909 4.56845 7.90909H19.4315C20.2978 7.90909 21 7.20687 21 6.34064V4.56845C21 3.70222 20.2978 3 19.4315 3Z"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path d="M7.09091 7.90909V3" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M8.72726 3V7.90909" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M15.2727 7.90909V3" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M16.9091 3V7.90909" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M14.4545 14.4545H12.4091H9.54544" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M18.5455 9.54547V11.3512C18.5319 12.0541 18.2826 12.732 17.8374 13.2761C17.3923 13.8202 16.7772 14.199 16.0909 14.3515" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path d="M7.9091 14.3515C7.22284 14.199 6.60774 13.8202 6.1626 13.2761C5.71745 12.732 5.46809 12.0541 5.45456 11.3512V9.54547" stroke="#C7D2FE" stroke-linecap="round" stroke-linejoin="round"></path>
                                <path
                                    d="M18.5454 21H20.5909C20.6994 21 20.8034 20.9569 20.8802 20.8802C20.9569 20.8034 21 20.6994 21 20.5909V16.9091C21 16.2581 20.7414 15.6338 20.2811 15.1734C19.8208 14.7131 19.1964 14.4545 18.5454 14.4545"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M5.45455 21H3.40909C3.30059 21 3.19654 20.9569 3.11982 20.8802C3.0431 20.8034 3 20.6994 3 20.5909V16.9091C3 16.2581 3.2586 15.6338 3.71892 15.1734C4.17924 14.7131 4.80356 14.4545 5.45455 14.4545V14.4545"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M18.5455 11.5909V21C18.5455 21.217 18.4593 21.4251 18.3058 21.5785C18.1524 21.732 17.9443 21.8182 17.7273 21.8182H6.27274C6.05575 21.8182 5.84764 21.732 5.6942 21.5785C5.54076 21.4251 5.45456 21.217 5.45456 21V11.5909"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M9.54545 15.2727C9.54545 15.4897 9.45925 15.6978 9.30581 15.8513C9.15237 16.0047 8.94427 16.0909 8.72727 16.0909C8.51027 16.0909 8.30217 16.0047 8.14873 15.8513C7.99529 15.6978 7.90909 15.4897 7.90909 15.2727V13.2273C7.90909 13.1188 7.95219 13.0147 8.02891 12.938C8.10563 12.8613 8.20968 12.8182 8.31818 12.8182H9.13636C9.24486 12.8182 9.34891 12.8613 9.42563 12.938C9.50235 13.0147 9.54545 13.1188 9.54545 13.2273V15.2727Z"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                                <path
                                    d="M16.0909 15.2727C16.0909 15.4897 16.0047 15.6978 15.8513 15.8513C15.6978 16.0047 15.4897 16.0909 15.2727 16.0909C15.0557 16.0909 14.8476 16.0047 14.6942 15.8513C14.5408 15.6978 14.4546 15.4897 14.4546 15.2727V13.2273C14.4546 13.1188 14.4977 13.0147 14.5744 12.938C14.6511 12.8613 14.7552 12.8182 14.8637 12.8182H15.6818C15.7903 12.8182 15.8944 12.8613 15.9711 12.938C16.0478 13.0147 16.0909 13.1188 16.0909 13.2273V15.2727Z"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                        </span>
                        CHOOSE A PRE-ASSEMBLED RIG
                    </h2>
                    <div class="package-list" id="first">
                        <div class="order-package" data-cy="order-package-0" id="first_one">
                            <button type="button" data-cy="add-order-package" aria-label="add package to cart" data-testid="package-add">
                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-package-0">
                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                    <path data-amount1="4800" data-amount2="2000" data-name="Anonymizer" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </button>
                            <div type="button" aria-label="open/close package" class="order-container" data-testid="order-package" style="margin: 0.75rem 0px;">
                                <div class="package-top">
                                    <div class="package-top-left" style="padding-left: 3.75rem;">
                                        <div>
                                            <div class="package-title">Anonymizer</div>
                                            <p class="package-desc">Mask who controls your offshore company by using Nominees</p>
                                        </div>
                                    </div>
                                    <div class="package-top-right">
                                        <p class="package-currency">US$</p>
                                        <p class="package-price">11,630.00</p>
                                        <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                </div>
                                <hr>
                                <div style="opacity: 1; height: auto;" class="clickopen">
                                <div class="package-bottom">
                                    <div class="package-service">
                                        <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                fill="#818CF8"
                                            ></path>
                                        </svg>
                                        <p class="service-title">Corporate Nominee Director</p>
                                        <div class="infotip">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                    stroke="#6B7280"
                                                    stroke-width="1.5"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                ></path>
                                            </svg>
                                        </div>
                                        <p class="service-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                    </div>
                                    <div class="package-service">
                                        <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                fill="#818CF8"
                                            ></path>
                                        </svg>
                                        <p class="service-title">Full KYC / AML kit</p>
                                        <div class="infotip">
                                            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                    stroke="#6B7280"
                                                    stroke-width="1.5"
                                                    stroke-linecap="round"
                                                    stroke-linejoin="round"
                                                ></path>
                                            </svg>
                                        </div>
                                        <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                    </div>
                                </div>
                            </div>

                            </div>
                        </div>
                        <div class="order-package" data-cy="order-package-1" id="first_two">
                            <button type="button" data-cy="add-order-package" aria-label="add package to cart" data-testid="package-add">
                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-package-1">
                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                    <path data-amount1="2000" data-name="Prop"  transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </button>
                            <div type="button" aria-label="open/close package" class="order-container" data-testid="order-package" style="margin: 0.75rem 0px;">
                                <div class="package-top">
                                    <div class="package-top-left" style="padding-left: 3.75rem;">
                                        <div>
                                            <div class="package-title">Prop Trading</div>
                                            <p class="package-desc">Hold and trade digital assets on both CEX and DEX</p>
                                        </div>
                                    </div>
                                    <div class="package-top-right">
                                        <p class="package-currency">US$</p>
                                        <p class="package-price">6,830.00</p>
                                        <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                </div>
                                <hr>
                                <div style="opacity: 1; height: auto;" class="clickopen">
                                    <div class="package-bottom">
                                        <div class="package-service">
                                            <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                    fill="#818CF8"
                                                ></path>
                                            </svg>
                                            <p class="service-title">Full KYC / AML kit</p>
                                            <div class="infotip">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                        stroke="#6B7280"
                                                        stroke-width="1.5"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                    ></path>
                                                </svg>
                                            </div>
                                            <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                        </div>
                                    </div>
                                </div>
                                    
                            </div>
                        </div>
                        <div class="order-package" data-cy="order-package-2" id="first_three">
                            <button type="button" data-cy="add-order-package" aria-label="add package to cart" data-testid="package-add">
                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-package-2">
                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                    <path data-amount1="4800" data-amount2="6000" data-amount3="2000" data-name="Token" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                </svg>
                            </button>
                            <div type="button" aria-label="open/close package" class="order-container" data-testid="order-package" style="margin: 0.75rem 0px;">
                                <div class="package-top">
                                    <div class="package-top-left" style="padding-left: 3.75rem;">
                                        <div>
                                            <div class="package-title">Token Issuance</div>
                                            <p class="package-desc">Ideal for fair launches and airdrops</p>
                                        </div>
                                    </div>
                                    <div class="package-top-right">
                                        <p class="package-currency">US$</p>
                                        <p class="package-price">17,630.00</p>
                                        <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path data-amount1="4800" data-name="Corporate" d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                        </svg>
                                    </div>
                                </div>
                                <hr>
                                <div style="opacity: 1; height: auto;" class="clickopen">
                                    <div class="package-bottom">
                                        <div class="package-service">
                                            <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                    fill="#818CF8"
                                                ></path>
                                            </svg>
                                            <p class="service-title">Corporate Nominee Director</p>
                                            <div class="infotip">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                        stroke="#6B7280"
                                                        stroke-width="1.5"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                    ></path>
                                                </svg>
                                            </div>
                                            <p class="service-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                        </div>
                                        <div class="package-service">
                                            <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                    fill="#818CF8"
                                                ></path>
                                            </svg>
                                            <p class="service-title">Legal opinion on nature of token</p>
                                            <div class="infotip">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                        stroke="#6B7280"
                                                        stroke-width="1.5"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                    ></path>
                                                </svg>
                                            </div>
                                            <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                        </div>
                                        <div class="package-service">
                                            <svg width="14" height="10" viewBox="0 0 14 10" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path
                                                    fill-rule="evenodd"
                                                    clip-rule="evenodd"
                                                    d="M13.7071 0.292893C14.0976 0.683417 14.0976 1.31658 13.7071 1.70711L5.70711 9.70711C5.31658 10.0976 4.68342 10.0976 4.29289 9.70711L0.292893 5.70711C-0.0976311 5.31658 -0.0976311 4.68342 0.292893 4.29289C0.683417 3.90237 1.31658 3.90237 1.70711 4.29289L5 7.58579L12.2929 0.292893C12.6834 -0.0976311 13.3166 -0.0976311 13.7071 0.292893Z"
                                                    fill="#818CF8"
                                                ></path>
                                            </svg>
                                            <p class="service-title">Legal and tax intel</p>
                                            <div class="infotip">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                        stroke="#6B7280"
                                                        stroke-width="1.5"
                                                        stroke-linecap="round"
                                                        stroke-linejoin="round"
                                                    ></path>
                                                </svg>
                                            </div>
                                            <p class="service-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                        </div>
                                    </div>
                                </div>  
                            </div>
                        </div>
                    </div>
                </div> -->
                <div class="option-container">
                    <h2>
                        <span>
                            <svg width="20" height="18" viewBox="0 0 20 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M7 17L1.55279 14.2764C1.214 14.107 1 13.7607 1 13.382V2.61803C1 1.87465 1.78231 1.39116 2.44721 1.72361L7 4M7 17L13 14M7 17V4M13 14L17.5528 16.2764C18.2177 16.6088 19 16.1253 19 15.382V4.61803C19 4.23926 18.786 3.893 18.4472 3.72361L13 1M13 14V1M13 1L7 4"
                                    stroke="#C7D2FE"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                        </span>
                        HANDPICK EXTRA GEAR
                    </h2>
                    <div class="options-wrapper">
                        <div class="option-section-last-icon">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M8 8H3.23607C1.74931 8 0.782315 9.56463 1.44722 10.8944L4.94722 17.8944C5.286 18.572 5.97853 19 6.73607 19H10.7538C10.9173 19 11.0802 18.9799 11.2389 18.9403L15 18M8 8V3C8 1.89543 8.89543 1 10 1H10.0955C10.595 1 11 1.40497 11 1.90453C11 2.61883 11.2114 3.31715 11.6077 3.91149L15 9V18M8 8H10M15 18H17C18.1046 18 19 17.1046 19 16V10C19 8.89543 18.1046 8 17 8H14.5"
                                    stroke="white"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                        </div>
                        <div>
                            <div class="option-section">
                                <div class="option-section-top">
                                    <div class="option-section-order-icon">1</div>
                                    <div class="option-section-title">Entity Management</div>
                                    <div class="infotip">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                stroke="#6B7280"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                            ></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="option-list">
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-0">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-0">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="4800" data-onetime="0" data-annual="4800" data-name="Director" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Corporate Nominee Director</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">4,800.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Our Nominee Services also include the appointment of corporate director(s) to your entity, creating an extra layer of distance between you as controller and the company itself. Our Corporate Directors act under a signed Nominee
                                                        Director Agreement which leaves no room for the Nominee(s) to act on behalf of your Company without written instructions from you. Note that if we are Nominee Director, you will need to have us involved with all Bank and
                                                        Exchange/OTC account openings as per our standard tariff and we will have corresponding information rights.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-1">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-1">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="1200" data-onetime="0" data-annual="1200" data-name="Nominee" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Nominee Shareholder</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">1,200.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Our Nominee Shareholder service offers privacy and asset protection in jurisdictions with a public register of companies which typically includes details of companies' shareholders including residential address. Whilst a Nominee
                                                        Shareholder would still require you to comply with KYC as the company's Ultimate Beneficial Owner, it does offer privacy and can shield assets from preying eyes and/or creditors. Note that if Otonomos provides Nominee
                                                        Shareholder(s), you will need to have us involved with all Bank and Exchange/OTC account openings as per our standard tariff and we will have corresponding information rights.
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-2">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-2">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="2000" data-onetime="2000" data-annual="0" data-name="KYC" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Full KYC / AML kit</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">2,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Our comprehensive Full KYC/AML Kit, available for a one-time fee of US$2,000, equips you with a certified or notarized set of essential corporate documents, potentially being vital for the onboarding process with banks,
                                                        centralized exchanges, and Over-The-Counter desks. This indispensable KYC kit includes the Certificate of Incorporation, your entity's Constitution (M&amp;A or Operating Agreement), the Register of Directors, and the Register of
                                                        Members/Shareholders. With these vital documents at your disposal, you can confidently navigate the onboarding procedures, ensuring a more seamless and compliant entry into the financial landscape. Note this document suite is
                                                        often required when opening a subsidiary of your company or when doing an asset pledge.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-3">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-3">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="89" data-onetime="0" data-annual="89" data-name="Bahamas" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Securities Bahamas Commission Annual Fee</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(76, 29, 149);">Annually</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">89.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>Annual renewal</p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="option-section">
                                <div class="option-section-top">
                                    <div class="option-section-order-icon">2</div>
                                    <div class="option-section-title">Crypto Exchange/OTC Account</div>
                                    <div class="infotip">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                stroke="#6B7280"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                            ></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="option-list">
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-0">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-0">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="1200"  data-onetime="1200" data-annual="0"  data-name="Kraken" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Kraken exchange account opening</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">1,200.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Leverage the advanced trading features offered by Kraken with ease. Our streamlined service involves opening a Kraken Exchange account on behalf of your entity. Once the account is successfully established, we promptly transfer
                                                        the login credentials to you, ensuring you gain swift access to Kraken's sophisticated trading platform. This hassle-free process allows you to harness the full potential of Kraken's trading capabilities efficiently saving your
                                                        valuable time.
                                                    </p>
                                                </div>
                                            </div>

                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-1">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-1">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="1200" data-onetime="1200" data-annual="0"  data-name="Skyline" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Skyline Digital OTC Account Opening</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">1,200.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Let us help open an account with our partner Skyline Digital. Their solution allows you to make fiat payments directly from your wallet using crypto in a self-custodial way. Once the account is successfully established, we
                                                        promptly transfer any login credentials to you, ensuring you gain quick access to your Skyline Account.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="option-section">
                                <div class="option-section-top">
                                    <div class="option-section-order-icon">3</div>
                                    <div class="option-section-title">Fiat Bank Account</div>
                                    <div class="infotip">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                stroke="#6B7280"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                            ></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="option-list">
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-0">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-0">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="7000" data-onetime="7000" data-annual="0"  data-name="Fiat" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Fiat bank account opening offshore</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">7,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Let us facilitate the process of opening a fiat bank account in the Caribbean through a reputable offshore financial institution. Our dedicated account opening service operates on a best-effort basis and is contingent upon the
                                                        final decision of our esteemed banking partners. Any supplementary services exceeding the essential requirements will be billed according to a time-spent basis at a rate of US$400 per hour.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div>
                            <div class="option-section">
                                <div class="option-section-top">
                                    <div class="option-section-order-icon">4</div>
                                    <div class="option-section-title">Paid Guides</div>
                                    <div class="infotip">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M9.83333 12.3333H9V9H8.16667M9 5.66667H9.00833M16.5 9C16.5 13.1421 13.1421 16.5 9 16.5C4.85786 16.5 1.5 13.1421 1.5 9C1.5 4.85786 4.85786 1.5 9 1.5C13.1421 1.5 16.5 4.85786 16.5 9Z"
                                                stroke="#6B7280"
                                                stroke-width="1.5"
                                                stroke-linecap="round"
                                                stroke-linejoin="round"
                                            ></path>
                                        </svg>
                                    </div>
                                </div>
                                <div class="option-list">
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-0">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-0">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="2000" data-onetime="2000" data-annual="0"  data-name="Saft" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">SAFT Guidance</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">2,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Our SAFT Guidance service is designed to help you navigate the complexities of preparing your Simple Agreement for Future Tokens (SAFT) for potential investors. We offer you a comprehensive SAFT template, expertly guide you
                                                        through its mechanics, and provide invaluable insights into potential pitfalls to watch out for. With our support, you can confidently present an investor-ready SAFT, ensuring that you're well-prepared for successful token
                                                        offerings and investment opportunities.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-1">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-1">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="2000" data-onetime="2000" data-annual="0"  data-name="Safte" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">SAFTE Guidance</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">2,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Our SAFTE Guidance service is your go-to resource for preparing your Simple Agreement for Future Tokens and/or Equity (SAFTE) to attract potential investors. The SAFTE structure provides the flexibility to convert into tokens
                                                        and/or equity, making it a powerful instrument for fundraising. We supply you with a meticulously crafted SAFTE template, offer step-by-step guidance through its intricacies, and provide crucial insights to steer clear of
                                                        potential pitfalls. With our assistance, your SAFTE will be investor-ready, equipping you to navigate token offerings and equity conversions with confidence and success.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-2">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-2">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="6000" data-onetime="6000" data-annual="0"  data-name="Legal" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Legal opinion on nature of token</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">6,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Harness the collective wisdom of Otonomos, cultivated through our extensive work with numerous clients, to potentially save you thousands of dollars by steering you toward your ideal corporate structure. Our initial guidance can
                                                        point you in the right direction, and if specific legal or tax advice is required, we collaborate with local counsel and tax advisors to provide tailored solutions. Our service operates on a flexible basis, with billing
                                                        structured per block of 5 hours at a rate of US$400 per hour. You have the liberty to procure additional blocks as needed, ensuring that you receive the precise support required to refine your corporate framework and achieve
                                                        optimal results.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                    <div class="order-option">
                                        <div>
                                            <button type="button" data-cy="add-order-option-button-3">
                                                <svg width="32" class="amt_get" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" data-cy="unchecked-order-option-3">
                                                    <circle cx="16" cy="16" r="15" stroke="#6366F1" stroke-width="2"></circle>
                                                    <path data-amount1="2000" data-onetime="2000" data-annual="0"  data-name="Intel" transform="translate(2, 2)" d="M14 9V14M14 14V19M14 14H19M14 14L9 14" stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg>
                                            </button>
                                        </div>
                                        <div class="option-container" data-testid="option-container">
                                            <div class="option-top" style="margin-bottom: 0rem;">
                                                <div class="option-top-left">
                                                    <div><h3 class="option-title">Legal and tax intel</h3></div>
                                                    <p class="option-tag" style="background-color: rgb(22, 78, 99);">One-time</p>
                                                </div>
                                                <div class="option-top-right">
                                                    <p class="option-currency">US$</p>
                                                    <p class="option-price">2,000.00</p>
                                                    <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                                    </svg>
                                                </div>
                                            </div>
                                            <hr>
                                            <div style="opacity: 1; height: auto;" class="clickopen">
                                                <div class="option-bottom">
                                                    <p>
                                                        Harness the collective wisdom of Otonomos, cultivated through our extensive work with numerous clients, to potentially save you thousands of dollars by steering you toward your ideal corporate structure. Our initial guidance can
                                                        point you in the right direction, and if specific legal or tax advice is required, we collaborate with local counsel and tax advisors to provide tailored solutions. Our service operates on a flexible basis, with billing
                                                        structured per block of 5 hours at a rate of US$400 per hour. You have the liberty to procure additional blocks as needed, ensuring that you receive the precise support required to refine your corporate framework and achieve
                                                        optimal results.
                                                    </p>
                                                </div>
                                            </div>
                                                
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="order-page-right">
            <div class="cart">
                <hr />
                <div class="cart-title">
                    <span>
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path
                                d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                                stroke="#C7D2FE"
                                stroke-width="1.5"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                            ></path>
                        </svg>
                    </span>
                    <p class="title-text">YOUR CART</p>
                </div>
                <button class="cart-title-mobile" data-cy="mobile-cart-button" type="button" aria-label="open cart" style="margin: 1rem 0px 0px;">
                    <div class="cart-title-mobile-row">
                        <div class="cart-title-mobile-row-left" data-cy="cypress-cart-modal-open">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M1 1H3L3.4 3M5 11H15L19 3H3.4M5 11L3.4 3M5 11L2.70711 13.2929C2.07714 13.9229 2.52331 15 3.41421 15H15M15 15C13.8954 15 13 15.8954 13 17C13 18.1046 13.8954 19 15 19C16.1046 19 17 18.1046 17 17C17 15.8954 16.1046 15 15 15ZM7 17C7 18.1046 6.10457 19 5 19C3.89543 19 3 18.1046 3 17C3 15.8954 3.89543 15 5 15C6.10457 15 7 15.8954 7 17Z"
                                    stroke="#C7D2FE"
                                    stroke-width="1.5"
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                ></path>
                            </svg>
                            <p>YOUR CART</p>
                        </div>
                        <p class="mobile-total cart_total">US$ 4,830.00</p>
                    </div>
                </button>
                <div class="mobile-display">
                    <div class="cart-scroll" data-cy="cart-scroller">
                        <div>
                            <div class="cart-product" data-cy="cart-product-0">
                                <div class="product-title">
                                    <button data-cy="cart-product-item-0" class="product-title-link" type="button">Bahamas IBC</button>
                                    <button type="button" data-testid="product-remove-from-cart" data-cy="product-remove-from-cart-0" aria-label="remove item from cart">
                                        <svg width="8" height="8" viewBox="0 0 8 8" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                fill-rule="evenodd"
                                                clip-rule="evenodd"
                                                d="M0.575791 0.575821C0.810105 0.341507 1.19 0.341507 1.42432 0.575821L4.00006 3.15156L6.57579 0.575821C6.81011 0.341507 7.19 0.341507 7.42432 0.575821C7.65863 0.810136 7.65863 1.19003 7.42432 1.42435L4.84858 4.00009L7.42432 6.57582C7.65863 6.81014 7.65863 7.19004 7.42432 7.42435C7.19 7.65866 6.81011 7.65866 6.57579 7.42435L4.00006 4.84861L1.42432 7.42435C1.19 7.65866 0.810105 7.65866 0.575791 7.42435C0.341476 7.19004 0.341476 6.81014 0.575791 6.57582L3.15153 4.00009L0.575791 1.42435C0.341476 1.19003 0.341476 0.810136 0.575791 0.575821Z"
                                                fill="white"
                                            ></path>
                                        </svg>
                                    </button>
                                </div>
                                <div class="cart-total">
                                    <p style="margin-left: 1rem;">Total:</p>
                                    <p style="text-align: right; margin-right: 0.5rem;" class="cart_total">
                                        US$ 4,830.00
                                        <span>
                                            <svg width="14" height="9" viewBox="0 0 14 9" fill="none" xmlns="http://www.w3.org/2000/svg" style="margin-left: 1rem;">
                                                <path d="M12.8333 1.5L7.00001 7.33333L1.16667 1.5" stroke="#6B7280" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"></path>
                                            </svg>
                                        </span>
                                    </p>
                                </div>
                                <div style="opacity: 1; height: auto;">
                                    <div class="cart-section">
                                        <h5 class="cart-section-title">Required Services</h5>
                                        <div class="cart-section-row">
                                            <p>One-time required</p>
                                            <p style="margin-right: 0.5rem;">2,680.00</p>
                                        </div>
                                        <div class="cart-section-row">
                                            <p>Annually required</p>
                                            <p style="margin-right: 0.5rem;">2,150.00</p>
                                        </div>
                                    </div>
                                    <div class="cart-section">
                                        <h5 class="cart-addons-title">Add-ons</h5>
                                        <div class="cart-section-row">
                                            <p>One-time Add-on</p>
                                            <p style="margin-right: 0.5rem;" id="onetime_addon">0.00</p>
                                        </div>
                                        <div class="cart-section-row">
                                            <p>Annual Add-on</p>
                                            <p style="margin-right: 0.5rem;" id="annual_addon">0.00</p>
                                        </div>
                                    </div>
                                </div>
                                <hr class="product-brake" style="margin-top: 0.75rem;" />
                            </div>
                        </div>
                    </div>
                    <div class="cart-section cart-bottom">
                        <div class="cart-total">
                            <p>Cart Total</p>
                            <p style="margin-right: 0.5rem;" class="cart_total">US$ 4,830.00</p>
                        </div>
                        <button type="button" aria-label="checkout button" class="checkout">Checkout</button>
                        <!-- <button class="add-jurisdiction" type="button" aria-label="checkout button">Add Another Jurisdiction</button> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\otonomous\resources\views/order.blade.php ENDPATH**/ ?>