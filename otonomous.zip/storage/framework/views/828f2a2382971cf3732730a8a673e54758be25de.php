
<?php $__env->startSection('content'); ?>

    <div class="landing-container">
        <video autoplay muted loop  class="hero-vid">
            <source src="<?php echo e(asset('assets/video/hero-vid-v2.2.mp4')); ?>" type="video/mp4">
            <source src="<?php echo e(asset('assets/video/hero-vid-v2.2.ogg')); ?>" type="video/ogg">
        </video>
        <img class="hero-img" src="https://otonomos-web-public-assets.s3.us-west-2.amazonaws.com/heroImg-v2.png" alt="A campfire and tent infront of a stary night sky with a constellation of a unicorn.">
        <div class="hero-text">
            <h1>Incorporation kits for your 
                <span>trek into tech</span>
            </h1>
            <h3>Otonomos helps builders and investors in crypto and tech form and maintain their legal entities in all major jurisdictions around the world. 
                <br><br>Assemble your gear today and start building from anywhere.
            </h3>
            <a class="call-to-action" href="https://calendly.com/d/dmf-tys-ssx" target="_blank" rel="noopener noreferrer">
                <p>Book Free Call</p>
            </a>
        </div>
    </div>
    <div class="offchain-display">
        <div class="offchain-title-container">
            <h5>Shop Jurisdictions</h5>
            <h2>Filter your needs, order online, pay in crypto or fiat</h2>
            <p>Incorporate a legal entity within days in all major locations around the world</p>
        </div>
        <div style="opacity: 1;">

            <div class="product-filter-container">
                <button class="filter-button current-tag" data-testid="false" type="button">all</button>
                <button class="filter-button second_btn" data-testid="filter-tag" type="button">Asset Protection</button>
                <button class="filter-button third_btn" data-testid="filter-tag" type="button">Banking</button>
                <button class="filter-button fourth_btn" data-testid="filter-tag" type="button">Crypto-Friendly</button>
                <button class="filter-button fifth_btn" data-testid="filter-tag" type="button">Digital Goods</button>
                <button class="filter-button sixth_btn" data-testid="filter-tag" type="button">Funds</button>
                <button class="filter-button seventh_btn" data-testid="filter-tag" type="button">Governance</button>
                <button class="filter-button eighth_btn" data-testid="filter-tag" type="button">holding</button>
                <button class="filter-button ninth_btn" data-testid="filter-tag" type="button">Investment Fund</button>
                <button class="filter-button tenth_btn" data-testid="filter-tag" type="button">OpCo</button>
                <button class="filter-button eleventh_btn" data-testid="filter-tag" type="button">Privacy</button>
                <button class="filter-button twelveth_btn" data-testid="filter-tag" type="button">Startup</button>
                <button class="filter-button thirtieth_btn" data-testid="filter-tag" type="button">Tax Optimized</button>
                <button class="filter-button fourteenth_btn" data-testid="filter-tag" type="button">Token Offering</button>
                <button class="filter-button fifteenth_btn" data-testid="filter-tag" type="button">Trading</button>
                <button class="filter-button sixteenth_btn" data-testid="filter-tag" type="button">VC Funding</button>
            </div>
            <div class="filter-dropdown">
                <select class="filter-display">
                    <option class="dropdown-option" value="All">All</option>
                    <option class="dropdown-option second_btn" value="Asset Protection">Asset Protection</option>
                    <option class="dropdown-option third_btn" value="Banking">Banking</option>
                    <option class="dropdown-option fourth_btn" value="Crypto-Friendly">Crypto-Friendly</option>
                    <option class="dropdown-option fifth_btn" value="Digital Goods">Digital Goods</option>
                    <option class="dropdown-option sixth_btn" value="Funds">Funds</option>
                    <option class="dropdown-option seventh_btn" value="Governance">Governance</option>
                    <option class="dropdown-option eighth_btn" value="Holding">Holding</option>
                    <option class="dropdown-option ninth_btn" value="Investment Fund">Investment Fund</option>
                    <option class="dropdown-option tenth_btn" value="Privacy">OpCo</option>
                    <option class="dropdown-option eleventh_btn" value="Privacy">Privacy</option>
                    <option class="dropdown-option twelveth_btn" value="Startup">Startup</option>
                    <option class="dropdown-option thirtieth_btn" value="Tax Optimized">Tax Optimized</option>
                    <option class="dropdown-option fourteenth_btn" value="Token Offering">Token Offering</option>
                    <option class="dropdown-option fifteenth_btn" value="Trading">Trading</option>
                    <option class="dropdown-option sixteenth_btn" value="VC Funding">VC Funding</option>
                </select>
            </div>
            <!-- <div class="filter-dropdown">
                <button class="filter-display" type="button">all
                    <span>
                        <svg width="8" height="14" viewBox="0 0 8 14" fill="none" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M4 0C4.26522 5.96046e-08 4.51957 0.105357 4.70711 0.292893L7.70711 3.29289C8.09763 3.68342 8.09763 4.31658 7.70711 4.70711C7.31658 5.09763 6.68342 5.09763 6.29289 4.70711L4 2.41421L1.70711 4.70711C1.31658 5.09763 0.683417 5.09763 0.292893 4.70711C-0.0976311 4.31658 -0.097631 3.68342 0.292893 3.29289L3.29289 0.292893C3.48043 0.105357 3.73478 0 4 0ZM0.292893 9.29289C0.683417 8.90237 1.31658 8.90237 1.70711 9.29289L4 11.5858L6.29289 9.29289C6.68342 8.90237 7.31658 8.90237 7.70711 9.29289C8.09763 9.68342 8.09763 10.3166 7.70711 10.7071L4.70711 13.7071C4.31658 14.0976 3.68342 14.0976 3.29289 13.7071L0.292893 10.7071C-0.0976311 10.3166 -0.0976311 9.68342 0.292893 9.29289Z" fill="#D1D5DB"></path>
                        </svg>
                    </span>
                </button>
            </div> -->
            <div class="product-display-container">
                <div style="opacity: 1;" class="fourth eighth thirtieth fourteenth fifteenth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link">
                            <div class="product-name">
                                <strong>Bahamas</strong>
                                <br>IBC
                            </div>
                            <hr>
                            <div class="product-desc">For token distribution, banking and holding purposes.</div>
                            <div class="product-price">US$ 2,680</div>
                            <div class="order-now" data-cy="test-selector-19">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Token Offering, Crypto-Friendly, Trading</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="second fourth sixth eighth ninth thirtieth fourteenth fifteenth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link " href="/order/1/new">
                            <div class="product-name">
                                <strong>BVI</strong>
                                <br>Limited Company
                            </div><hr>
                            <div class="product-desc">Unmatched Value for Your Holding, Special Purpose Vehicle, or Investment Fund.</div>
                            <div class="product-price">US$ 1,595</div>
                                <div class="order-now" data-cy="test-selector-1">Order online now →</div>
                                <div class="product-tags">holding, Tax Optimized, Investment Fund, Asset Protection, Token Offering, Crypto-Friendly, Trading, Funds
                            </div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;"  class="second eighth eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link " href="/order/43/new">
                            <div class="product-name">
                                <strong>BVI</strong>
                                <br>Trust
                            </div><hr>
                            <div class="product-desc">Elevate Your Wealth Protection and Safeguard Your Privacy.</div>
                            <div class="product-price">US$ 7,970</div>
                            <div class="order-now" data-cy="test-selector-43">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Asset Protection, Privacy</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third fifth tenth thirtieth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link " href="/order/2/new">
                            <div class="product-name">
                                <strong>Canada</strong>
                                <br>Limited Liability Partnership
                            </div>
                            <hr>
                            <div class="product-desc">Beneficial tax on non-Canadian earnings and excellent USD banking.</div>
                            <div class="product-price">US$ 995</div>
                            <div class="order-now" data-cy="test-selector-2">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, Digital Goods, OpCo</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth seventh eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link " href="/order/47/new">
                            <div class="product-name">
                                <strong>Cayman Islands</strong>
                                <br>Web 3.0 Foundation
                            </div>
                            <hr>
                            <div class="product-desc">
                                Long-term steward for your project, issuing grants to core contributors via its governance protocol.
                            </div>
                            <div class="product-price">US$ 7,420</div>
                            <div class="order-now" data-cy="test-selector-47">Order online now →</div>
                            <div class="product-tags">Tax Optimized, Crypto-Friendly, Privacy, Governance</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth seventh eighth eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card">
                        <a class="product-link " href="/order/4/new">
                            <div class="product-name">
                                <strong>Cayman Islands</strong>
                                <br>Private Foundation
                            </div><hr>
                            <div class="product-desc">
                                Versatile Wealth Management and Asset Protection vehicle that can be used similarly to a trust or a top level holding company
                            </div>
                            <div class="product-price">US$ 5,420</div>
                            <div class="order-now" data-cy="test-selector-4">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Crypto-Friendly, Privacy, Governance</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth eighth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/22/new">
                            <div class="product-name"><strong>Cayman Islands</strong><br>ELC</div>
                            <hr>
                            <div class="product-desc">Ideal for Prop-Trading and Asset Holding Structures for its tax optimization
                                possibilities.</div>
                            <div class="product-price">US$ 1,005</div>
                            <div class="order-now" data-cy="test-selector-22">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Crypto-Friendly</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fifth eighth tenth twelveth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/5/new">
                            <div class="product-name"><strong>Hong Kong</strong><br>Limited Company</div>
                            <hr>
                            <div class="product-desc">Freedom to entrepreneur from abroad with low or zero taxes.</div>
                            <div class="product-price">US$ 2,270</div>
                            <div class="order-now" data-cy="test-selector-5">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Digital Goods, OpCo, Startup</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third tenth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/49/new">
                            <div class="product-name"><strong>Ireland</strong><br>Limited Company</div>
                            <hr>
                            <div class="product-desc">Common Law jurisdiction inside the EU, great for software development or
                                operational companies.</div>
                            <div class="product-price">US$ 1,461</div>
                            <div class="order-now" data-cy="test-selector-49">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, OpCo</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth eighth tenth eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/50/new">
                            <div class="product-name"><strong>Isle of Man</strong><br>Limited Company</div>
                            <hr>
                            <div class="product-desc">Crypto receptive Common Law jurisdiction that puts an emphasis on privacy and has
                                a favourable tax regime.</div>
                            <div class="product-price">US$ 7,928</div>
                            <div class="order-now" data-cy="test-selector-50">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, OpCo, Crypto-Friendly, Privacy</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth eighth tenth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/58/new">
                            <div class="product-name"><strong>Malta</strong><br>Limited Company</div>
                            <hr>
                            <div class="product-desc">Crypto receptive EU jurisdiction with civil law influenced by common law creating
                                a favourable business environment. </div>
                            <div class="product-price">US$ 3,536</div>
                            <div class="order-now" data-cy="test-selector-58">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, OpCo, Crypto-Friendly</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth fifth eighth tenth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/45/new">
                            <div class="product-name"><strong>Marshall Islands</strong><br>LLC</div>
                            <hr>
                            <div class="product-desc"> All of the advantages of a US LLC with the added benefit of being offshore.
                            </div>
                            <div class="product-price">US$ 810</div>
                            <div class="order-now" data-cy="test-selector-45">Order online now →</div>
                            <div class="product-tags">holding, Tax Optimized, Digital Goods, OpCo, Crypto-Friendly</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="second fourth seventh eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/24/new">
                            <div class="product-name"><strong>Panama</strong><br>Foundation</div>
                            <hr>
                            <div class="product-desc">An ultra-private vehicle to hold assets and make grants.</div>
                            <div class="product-price">US$ 2,995</div>
                            <div class="order-now" data-cy="test-selector-24">Order online now →</div>
                            <div class="product-tags">Tax Optimized, Asset Protection, Crypto-Friendly, Privacy, Governance</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;"  class="second third fifth eleventh thirtieth fourteenth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/27/new">
                            <div class="product-name"><strong>Panama</strong><br>IBC</div>
                            <hr>
                            <div class="product-desc">A private, multi-purpose vehicle ideal for non-resident foreign citizens.</div>
                            <div class="product-price">US$ 1,495</div>
                            <div class="order-now" data-cy="test-selector-27">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, Asset Protection, Token Offering, Digital Goods, Privacy
                            </div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third tenth twelveth thirtieth sixteenth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/7/new">
                            <div class="product-name"><strong>Singapore</strong><br>Limited Company</div>
                            <hr>
                            <div class="product-desc">Establish a regional operational base in Asia with a potential pathway to
                                residency.</div>
                            <div class="product-price">US$ 880</div>
                            <div class="order-now" data-cy="test-selector-7">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, OpCo, Startup, VC Funding</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="second third fourth seventh all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/17/new">
                            <div class="product-name"><strong>Switzerland</strong><br>Foundation</div>
                            <hr>
                            <div class="product-desc">For decentralized projects with a political tint or global development angle.
                            </div>
                            <div class="product-price">US$ 6,170</div>
                            <div class="order-now" data-cy="test-selector-17">Order online now →</div>
                            <div class="product-tags">Banking, Asset Protection, Crypto-Friendly, Governance</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third fourth tenth eleventh twelveth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/8/new">
                            <div class="product-name"><strong>Switzerland</strong><br>GmbH (Zug)</div>
                            <hr>
                            <div class="product-desc">Prestige and privacy in the heart of Switzerland's Crypto Valley.</div>
                            <div class="product-price">US$ 11,095</div>
                            <div class="order-now" data-cy="test-selector-8">Order online now →</div>
                            <div class="product-tags">Banking, OpCo, Crypto-Friendly, Privacy, Startup</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fourth tenth thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/56/new">
                            <div class="product-name"><strong>UAE</strong><br>Freezone Company</div>
                            <hr>
                            <div class="product-desc">Flexible tax optimized entity in the Freezone that best suits your needs.</div>
                            <div class="product-price">US$ 5,100</div>
                            <div class="order-now" data-cy="test-selector-56">Order online now →</div>
                            <div class="product-tags">Tax Optimized, OpCo, Crypto-Friendly</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="fifth tenth twelveth sixteenth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/9/new">
                            <div class="product-name"><strong>UK</strong><br>Limited Liability Partnership</div>
                            <hr>
                            <div class="product-desc">A tax-optimized UK entity for foreign builders.</div>
                            <div class="product-price">US$ 180</div>
                            <div class="order-now" data-cy="test-selector-9">Order online now →</div>
                            <div class="product-tags">Digital Goods, OpCo, Startup, VC Funding</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third seventh tenth twelveth sixteenth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/11/new">
                            <div class="product-name"><strong>US - Delaware</strong><br>C-Corp</div>
                            <hr>
                            <div class="product-desc">The Gold Standard for Tech Startups, Ideal for Attracting both US and
                                International Investment</div>
                            <div class="product-price">US$ 427</div>
                            <div class="order-now" data-cy="test-selector-11">Order online now →</div>
                            <div class="product-tags">Banking, OpCo, Startup, VC Funding, Governance</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third sixth fifth ninth tenth thirtieth fifteenth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/10/new">
                            <div class="product-name"><strong>US - Delaware</strong><br>LLC</div>
                            <hr>
                            <div class="product-desc">Versatile company type for global digital good sales, software development, US
                                based operations, or as an Investment Fund/Feeder</div>
                            <div class="product-price">US$ 279</div>
                            <div class="order-now" data-cy="test-selector-10">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, Investment Fund, Digital Goods, OpCo, Trading, Funds</div>
                        </a>
                    </div>
                </div>
                <div style="opacity: 1;" class="third fourth fifth tenth eleventh thirtieth all">
                    <div class="product-card" data-testid="product-card"><a class="product-link " href="/order/12/new">
                            <div class="product-name"><strong>US - Wyoming</strong><br>LLC</div>
                            <hr>
                            <div class="product-desc">Optimal Privacy, Tax Benefits, and US Banking for Location-Independent Operations
                                and Software Development.</div>
                            <div class="product-price">US$ 249</div>
                            <div class="order-now" data-cy="test-selector-12">Order online now →</div>
                            <div class="product-tags">Banking, Tax Optimized, Digital Goods, OpCo, Crypto-Friendly, Privacy</div>
                        </a>
                    </div>
                </div> 
            </div>   
        </div>  
        <div class="payment-options">
            <p>We accept payment in all major crypto as well as via card and bank wire</p>
            <div class="crypto-icons">
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Etherium">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M24 48C37.2548 48 48 37.2548 48 24C48 10.7452 37.2548 0 24 0C10.7452 0 0 10.7452 0 24C0 37.2548 10.7452 48 24 48ZM24.1578 7.0985C24.0806 6.96592 23.889 6.96605 23.812 7.09874L14.2771 23.5244C14.2226 23.6182 14.2529 23.7384 14.3453 23.7952L23.8802 29.6526C23.9443 29.692 24.0251 29.6921 24.0893 29.6528L33.6542 23.7953C33.747 23.7385 33.7773 23.618 33.7226 23.5241L24.1578 7.0985ZM24.047 32.4877C23.9813 32.5299 23.897 32.5299 23.8313 32.4879L14.9684 26.8208C14.7866 26.7045 14.575 26.9187 14.6935 27.0991L23.7717 40.9201C23.8508 41.0404 24.0273 41.0403 24.1062 40.9198L33.1555 27.0998C33.2737 26.9193 33.0618 26.7054 32.8802 26.8219L24.047 32.4877Z" fill="white">
                    </path>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Bitcoin">
                    <g>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M18.1923 47.2819C31.0524 50.4864 44.0738 42.6624 47.2803 29.8061C50.4847 16.9478 42.6607 3.92255 29.8025 0.718074C16.9481 -2.48833 3.92473 5.33759 0.720252 18.1978C-2.48615 31.0541 5.33977 44.0755 18.1923 47.2819ZM29.3032 14.5248C32.6287 15.671 35.0594 17.3875 34.5832 20.5805C34.2357 22.919 32.9397 24.0499 31.2175 24.4454C33.581 25.6762 34.781 27.5635 33.6367 30.8333C32.2178 34.8941 28.8405 35.2378 24.3496 34.3872L23.2591 38.7552L20.6268 38.0986L21.702 33.7901C21.0184 33.6192 20.3215 33.4406 19.6034 33.2448L18.5224 37.5744L15.892 36.9178L16.9826 32.5421C16.7441 32.481 16.5041 32.4184 16.2625 32.3554C15.8817 32.2561 15.4967 32.1557 15.1068 32.0582L11.6796 31.2038L12.9871 28.1894C12.9871 28.1894 14.9282 28.7059 14.9013 28.6675C15.6482 28.8518 15.9784 28.3661 16.109 28.0416L17.8332 21.1392L18.1116 21.2083C18.006 21.1661 17.91 21.1392 17.837 21.12L19.0658 16.1914C19.0984 15.6307 18.9045 14.9261 17.8389 14.6592C17.8812 14.6304 15.9266 14.183 15.9266 14.183L16.6274 11.3702L20.2581 12.2765L20.2543 12.2899C20.8015 12.4262 21.364 12.5549 21.9362 12.6854L23.0152 8.3616L25.6476 9.01824L24.5896 13.2576C25.2962 13.4189 26.0066 13.5821 26.6978 13.7549L27.748 9.5424L30.3823 10.199L29.3032 14.5248ZM20.9736 30.2097C23.1219 30.777 27.8189 32.0175 28.566 29.017C29.3291 25.9504 24.7772 24.9289 22.5554 24.4303C22.3066 24.3745 22.087 24.3252 21.9074 24.2803L20.4616 30.0768C20.6087 30.1133 20.7809 30.1588 20.9736 30.2097ZM22.9995 21.7403C24.7924 22.2186 28.6971 23.2601 29.3781 20.5344C30.0746 17.7415 26.2658 16.901 24.4129 16.4921C24.2074 16.4468 24.0259 16.4067 23.8773 16.3699L22.566 21.6269C22.6902 21.6578 22.8361 21.6967 22.9995 21.7403Z" fill="white">
                        </path>
                    </g>
                    <defs>
                        <clipPath id="clip0">
                            <rect width="48" height="48" fill="white"></rect>
                        </clipPath>
                    </defs>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Dai stable coin">
                    <g>
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M48.0002 24C48.0002 10.75 37.2583 0 24.0002 0C10.7502 0 0.000244141 10.75 0.000244141 24C0.000244141 37.25 10.7422 48 24.0002 48C37.2583 48 48.0002 37.2581 48.0002 24ZM34.0075 25.7017H24.8866V25.6936H15.9511C15.5882 25.6936 15.5882 25.6936 15.5882 25.3469V22.6775C15.5882 22.4678 15.6446 22.3953 15.8704 22.3953H34.0237C34.2172 22.3953 34.3059 22.4759 34.3059 22.6533C34.3785 23.5807 34.3785 24.5162 34.3059 25.4436C34.2898 25.7017 34.2011 25.7017 34.0075 25.7017ZM33.2927 19.2662C33.2918 19.2689 33.2908 19.2716 33.2898 19.2743V19.2662H33.2927ZM33.2898 19.0646C33.313 19.1265 33.3139 19.2031 33.2927 19.2662H33.3543C33.3301 19.3549 33.1769 19.3872 33.1769 19.3872H15.8624C15.5801 19.3872 15.5801 19.3307 15.5801 19.1049V13.7824C15.5801 13.5888 15.6124 13.5001 15.8382 13.5001H23.8946C24.7495 13.492 25.6043 13.5807 26.443 13.7662C28.1043 14.1614 29.6446 14.9436 30.943 16.0485C31.2092 16.242 31.435 16.4759 31.6366 16.7259C32.064 17.1453 32.435 17.613 32.7495 18.1211C32.9592 18.4194 33.1366 18.734 33.2898 19.0646ZM32.5237 28.8146C32.7817 28.7904 33.0317 28.7904 33.2898 28.8146C33.3955 28.871 33.3287 29.0507 33.3102 29.1004C33.3076 29.1075 33.3059 29.112 33.3059 29.113C32.3866 30.9114 30.9188 32.3872 29.1204 33.3227H29.0156C28.6688 33.5243 28.2979 33.7017 27.9188 33.8307C26.8704 34.2259 25.7737 34.4678 24.6608 34.5485C24.2979 34.6211 23.935 34.6452 23.564 34.6211H15.8866C15.5882 34.6211 15.5882 34.5646 15.5882 34.3227V29.113C15.5882 28.8146 15.6608 28.8146 15.8866 28.8146H32.5237ZM12.572 37.3146V37.3227L12.564 37.3146H12.572ZM12.572 37.234V37.3146H22.9511C24.1285 37.3307 25.2979 37.242 26.4591 37.0323C27.6769 36.7985 28.8624 36.4194 29.9995 35.9114C30.5267 35.6616 31.0361 35.3641 31.548 35.0651C31.6312 35.0165 31.7145 34.9679 31.7979 34.9194C32.3543 34.5162 32.8946 34.0888 33.4027 33.6291C34.7979 32.3711 35.8785 30.7985 36.5559 29.0404C36.6043 28.8469 36.7898 28.7178 36.9914 28.7582H39.8301C40.0559 28.7582 40.1285 28.6856 40.1285 28.4275V26.613C40.1446 26.4356 40.1446 26.2662 40.1285 26.0888C40.1285 26.0428 40.1403 25.9977 40.152 25.9529C40.1753 25.8642 40.1982 25.7767 40.1285 25.6856H37.7575C37.4753 25.6856 37.4753 25.6614 37.4753 25.4033C37.5559 24.492 37.5559 23.5727 37.4753 22.6614C37.4672 22.3953 37.5237 22.3953 37.7333 22.3953H39.8059C40.0479 22.3953 40.1366 22.3388 40.1366 22.0969V19.6372C40.1286 19.4745 40.1246 19.3918 40.0812 19.3499C40.0365 19.3065 39.9498 19.3065 39.7737 19.3065H37.0882C36.8785 19.3469 36.6769 19.2017 36.6366 18.992C36.3301 18.1856 35.943 17.4114 35.4672 16.6936C34.9914 15.984 34.4592 15.3146 33.8624 14.7017C33.0721 13.9114 32.185 13.2259 31.2253 12.6614C29.7737 11.8146 28.185 11.2259 26.5317 10.9194C25.7333 10.7743 24.9188 10.6856 24.1043 10.6533H12.8543C12.5559 10.6533 12.5559 10.7098 12.5559 10.9517V19.0404C12.5559 19.3227 12.4995 19.3227 12.2737 19.3227H9.04784C8.80591 19.3227 8.80591 19.3711 8.80591 19.5324V22.1694C8.80591 22.4114 8.88655 22.4114 9.06397 22.4114H12.322C12.564 22.4114 12.564 22.4598 12.564 22.6372V25.4598C12.564 25.7178 12.4914 25.7178 12.2978 25.7178H8.81397V28.5646C8.81397 28.8065 8.89462 28.8065 9.07204 28.8065H12.3301C12.572 28.8065 12.572 28.8388 12.572 29.0323V32.5565V33.742V37.234Z" fill="white">
                        </path>
                    </g>
                    <defs>
                        <clipPath id="clip0">
                            <rect width="48" height="48" fill="white"></rect>
                        </clipPath>
                    </defs>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="TetherUSD">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M48 24C48 37.2548 37.2548 48 24 48C10.7452 48 0 37.2548 0 24C0 10.7452 10.7452 0 24 0C37.2548 0 48 10.7452 48 24ZM13.125 13H35V18.4688H27.1875V20.9093C33.45 21.304 38.125 22.8597 38.125 24.7188C38.125 26.5778 33.45 28.1335 27.1875 28.5282V38H20.9375V28.5282C14.675 28.1335 10 26.5778 10 24.7188C10 22.8597 14.675 21.304 20.9375 20.9093V18.4688H13.125V13ZM33.588 25.9754C31.2143 26.6347 27.846 27.0625 24.0625 27.0625C20.279 27.0625 16.9107 26.6347 14.537 25.9754C13.3392 25.6427 12.4831 25.2749 11.9628 24.9332C11.8322 24.8474 11.74 24.7756 11.6756 24.7188C11.74 24.6619 11.8322 24.5901 11.9628 24.5043C12.4831 24.1626 13.3392 23.7948 14.537 23.4621C16.2331 22.991 18.4371 22.6381 20.9375 22.475V25.5H27.1875V22.475C29.6879 22.6381 31.8919 22.991 33.588 23.4621C34.7858 23.7948 35.6419 24.1626 36.1622 24.5043C36.2928 24.5901 36.385 24.6619 36.4494 24.7188C36.385 24.7756 36.2928 24.8474 36.1622 24.9332C35.6419 25.2749 34.7858 25.6427 33.588 25.9754ZM36.5896 24.5656C36.5898 24.5651 36.5899 24.5649 36.5898 24.5649C36.5897 24.5648 36.5885 24.5668 36.5867 24.5708C36.5883 24.5682 36.5892 24.5665 36.5896 24.5656ZM11.5352 24.5649C11.5353 24.5648 11.5365 24.5668 11.5383 24.5708C11.5359 24.5669 11.535 24.5649 11.5352 24.5649ZM11.5352 24.8726C11.535 24.8726 11.5359 24.8706 11.5383 24.8667C11.5365 24.8707 11.5353 24.8727 11.5352 24.8726ZM36.5867 24.8667C36.5891 24.8706 36.59 24.8726 36.5898 24.8726C36.5897 24.8727 36.5885 24.8707 36.5867 24.8667Z" fill="white">
                    </path>
                </svg> 
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none"
                    xmlns="http://www.w3.org/2000/svg" alt="Zcash">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M24 48C37.2548 48 48 37.2548 48 24C48 10.7452 37.2548 0 24 0C10.7452 0 0 10.7452 0 24C0 37.2548 10.7452 48 24 48ZM32.9582 29.9713H22.5588C23.4716 29.0075 24.269 28.1588 25.0568 27.2065C27.1359 24.8065 29.1612 22.4641 31.1885 20.0641C31.3559 19.8692 31.5451 19.6745 31.7361 19.4778C32.2754 18.9228 32.8294 18.3526 32.9486 17.7217C33.1737 16.5836 33.1315 15.3951 33.0881 14.1722C33.0703 13.6724 33.0524 13.1669 33.0524 12.6567H26.5979V8.39243H21.4251V12.7623H15.5068V17.9848H25.4796C25.0829 18.4264 24.7076 18.838 24.3436 19.2371C23.8753 19.7506 23.4258 20.2435 22.9739 20.7534C20.8948 23.1534 18.8695 25.4958 16.8423 27.8958C16.6703 28.1137 16.4667 28.3313 16.2605 28.5517C15.7617 29.0849 15.2482 29.6337 15.134 30.2382C14.9084 31.3749 14.9514 32.565 14.9949 33.772C15.0125 34.2612 15.0303 34.7532 15.0303 35.2456H21.4328V39.5617H26.8208C26.7688 38.8148 26.7284 38.0943 26.6879 37.3734C26.6477 36.6563 26.6074 35.9386 26.5556 35.1937H32.9582V29.9713Z"
                        fill="white">
                    </path>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Monero">
                    <g>
                        <path fill-rule="evenodd" clip-rule="evenodd"
                            d="M0 24C0 10.7462 10.7462 0 24 0C37.2518 0 48 10.7462 48 24C48 26.6477 47.5699 29.1955 46.777 31.5802H39.6V11.3875L24 26.9875L8.4 11.3875V31.5802H1.22304C0.43008 29.1974 0 26.6496 0 24ZM13.6052 23.766L20.4135 30.5743L24.0001 34.1609L27.5866 30.5743L34.395 23.766V36.4726H44.5076C40.2951 43.3846 32.6862 48.0002 24.0001 48.0002C15.314 48.0002 7.70503 43.3846 3.49255 36.4726H13.6052V23.766Z"
                            fill="white">
                        </path>
                    </g>
                    <defs>
                        <clipPath id="clip0">
                            <rect width="48" height="48" fill="white"></rect>
                        </clipPath>
                    </defs>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="TrueUSD">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M48 24C48 37.2548 37.2548 48 24 48C10.7452 48 0 37.2548 0 24C0 10.7452 10.7452 0 24 0C37.2548 0 48 10.7452 48 24ZM35.625 12.975H27.525H27.075C23.175 13.2 20.1 16.425 20.025 20.325V20.475V36.975C20.025 37.125 20.1 37.2 20.25 37.2H27.825C27.975 37.2 28.05 37.125 28.05 36.975V27.975V21.15H34.95H35.625C35.7 21.15 35.775 21.075 35.775 21V13.125C35.775 13.05 35.7 12.975 35.625 12.975ZM12.3751 13.125H19.9501C20.0251 13.125 20.1001 13.125 20.1751 13.275V13.5C20.1751 17.7 16.7251 21.15 12.5251 21.15H12.2251V13.275C12.2251 13.2 12.3001 13.125 12.3751 13.125Z"
                        fill="white">
                    </path>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Solana">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M24 48C37.2548 48 48 37.2548 48 24C48 10.7452 37.2548 0 24 0C10.7452 0 0 10.7452 0 24C0 37.2548 10.7452 48 24 48ZM14.6823 30.0265C14.4182 30.0265 14.1659 30.1321 13.9781 30.3199L9.14876 35.1492C8.83189 35.4602 9.05487 36.0001 9.50084 36.0001H33.9409C34.205 36.0001 34.4573 35.8944 34.6451 35.7067L39.4744 30.8773C39.7913 30.5663 39.5683 30.0265 39.1224 30.0265H14.6823ZM13.9781 12.2934C14.1659 12.1056 14.4182 12 14.6823 12H39.1224C39.5683 12 39.7913 12.5399 39.4744 12.8509L34.6451 17.6743C34.4573 17.8621 34.205 17.9677 33.9409 17.9677H9.50084C9.05487 17.9677 8.83189 17.4279 9.14876 17.1169L13.9781 12.2934ZM33.9409 20.9545C34.205 20.9545 34.4573 21.0601 34.6451 21.2479L39.4744 26.0714C39.7913 26.3824 39.5683 26.9222 39.1224 26.9222H14.6823C14.4182 26.9222 14.1659 26.8166 13.9781 26.6288L9.14876 21.8053C8.83189 21.4943 9.05487 20.9545 9.50084 20.9545H33.9409Z"
                        fill="white">
                    </path>
                </svg>
                <svg width="48" height="48" viewBox="0 0 48 48" fill="none" xmlns="http://www.w3.org/2000/svg" alt="Fiat">
                    <path fill-rule="evenodd" clip-rule="evenodd"
                        d="M24 48C37.2548 48 48 37.2548 48 24C48 10.7452 37.2548 0 24 0C10.7452 0 0 10.7452 0 24C0 37.2548 10.7452 48 24 48ZM31.531 9.38516C31.146 8.23006 29.9909 7.58834 28.8358 7.84503L7.53076 13.7488C6.37566 14.1339 5.73394 15.289 5.99063 16.4441L6.50401 18.2409L31.9936 11.0035L31.531 9.38516ZM12.7795 23.5458C12.7795 22.3907 13.9479 21.1928 15.103 21.1928H34.868L33.01 14.4627L7.53076 21.8345L9.58426 29.2785C9.84095 30.4335 11.1244 31.2036 12.2795 30.8186L12.7929 30.6902L12.7795 23.5458ZM38.4056 22.2624H16.2021C15.047 22.2624 14.1486 23.1608 14.1486 24.4442V37.6636C14.1486 38.8187 15.047 39.8455 16.2021 39.8455H38.534C39.689 39.8455 40.7158 38.9471 40.7158 37.6636V24.3159C40.5875 23.1608 39.689 22.2624 38.4056 22.2624ZM20.3091 36.6369H15.8171V35.6101H20.3091V36.6369ZM26.4696 36.6369H21.9776V35.6101H26.4696V36.6369ZM32.8868 36.6369H28.3948V35.6101H32.8868V36.6369ZM32.2451 32.2732V30.0913C32.2451 29.4496 32.7585 29.0646 33.2719 29.0646H37.7639C38.4056 29.0646 38.7906 29.578 38.7906 30.0913V32.2732C38.7906 32.9149 38.2773 33.2999 37.7639 33.2999H33.2719C32.7585 33.2999 32.2451 32.9149 32.2451 32.2732ZM38.919 36.6369H34.427V35.6101H38.919V36.6369Z"
                        fill="white">
                    </path>
                </svg>
            </div>
        </div>
    </div>
    <div class="wizard-banner">
        <div class="top-fade"></div>
        <div class="wizard-banner-info">
            <div style="margin-top: 3rem; padding: 0px 0.5rem;">
                <h5>GUIDES</h5>
                <h3>Find your bearings</h3>
                <p>Use our Wizard or hire a guide to find the best base to build from</p>
            </div>
            <div class="button-link-container">
                <!-- <a href="https://wizard.otonomos.com/" target="_blank" class="wizard-link" rel="noopener noreferrer">
                    <p>Use Wizard</p>
                </a> -->
                <a class="wizard-link paid-call" href="https://calendly.com/d/2cf-2jw-6rn/fund-call" target="_blank"
                    rel="noopener noreferrer">
                    <p>Book Free Fund Call </p>
                </a>
            </div>
        </div>
        <div class="bottom-fade"></div>
    </div>
    <div class="client-display">
        <div class="client-info-display">
            <h2 class="clients-title">We set up hundreds of entities both offchain and onchain</h2>
            <div class="card-container">
                <div class="info-card">
                    <svg width="56" height="54" viewBox="0 0 56 54" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M54.8333 44.22C54.8333 46.3859 53.9729 48.4632 52.4414 49.9947C50.9098 51.5263 48.8326 52.3867 46.6667 52.3867H9.33334C7.1674 52.3867 5.09018 51.5263 3.55863 49.9947C2.02709 48.4632 1.16667 46.3859 1.16667 44.22C1.16667 42.0541 2.02709 39.9769 3.55863 38.4453C5.09018 36.9138 7.1674 36.0533 9.33334 36.0533H46.6667C48.8326 36.0533 50.9098 36.9138 52.4414 38.4453C53.9729 39.9769 54.8333 42.0541 54.8333 44.22Z"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                        <path
                            d="M18.3097 36.0534L25.179 23.9971C27.0498 20.7184 28.1214 17.045 28.3071 13.2748C28.4928 9.50455 27.7872 5.74363 26.2477 2.29705C26.1598 2.10058 26.0193 1.93223 25.8418 1.81063C25.6642 1.68903 25.4565 1.61892 25.2415 1.60806C25.0266 1.59719 24.8128 1.64599 24.6239 1.74905C24.435 1.85212 24.2782 2.00544 24.171 2.19205L3.07767 38.9701"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                        <path d="M22.8433 13.6697L16.4407 24.9023" stroke="#6366F1" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                        </path>
                        <path
                            d="M8.16667 44.2201C8.16667 45.1484 8.53542 46.0386 9.1918 46.695C9.84818 47.3513 10.7384 47.7201 11.6667 47.7201C12.5949 47.7201 13.4852 47.3513 14.1415 46.695C14.7979 46.0386 15.1667 45.1484 15.1667 44.2201C15.1667 43.2918 14.7979 42.4016 14.1415 41.7452C13.4852 41.0888 12.5949 40.7201 11.6667 40.7201C10.7384 40.7201 9.84818 41.0888 9.1918 41.7452C8.53542 42.4016 8.16667 43.2918 8.16667 44.2201V44.2201Z"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                        <path
                            d="M40.8333 44.2201C40.8333 45.1484 41.2021 46.0386 41.8585 46.695C42.5148 47.3513 43.4051 47.7201 44.3333 47.7201C45.2616 47.7201 46.1518 47.3513 46.8082 46.695C47.4646 46.0386 47.8333 45.1484 47.8333 44.2201C47.8333 43.2918 47.4646 42.4016 46.8082 41.7452C46.1518 41.0888 45.2616 40.7201 44.3333 40.7201C43.4051 40.7201 42.5148 41.0888 41.8585 41.7452C41.2021 42.4016 40.8333 43.2918 40.8333 44.2201V44.2201Z"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                        <path
                            d="M52.5 38.5034V15.0534C52.5 13.8157 52.0083 12.6287 51.1332 11.7536C50.258 10.8784 49.071 10.3867 47.8333 10.3867C46.5957 10.3867 45.4087 10.8784 44.5335 11.7536C43.6583 12.6287 43.1667 13.8157 43.1667 15.0534C45.829 15.5971 46.6667 17.9444 46.6667 20.7677C46.6667 23.5911 45.829 25.9431 43.1667 26.4844V36.0511"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                    </svg>
                    <h3>14</h3>
                    <p>Jurisdictions</p>
                </div>
                <div class="info-card">
                    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M33.0633 1.16663L1.37667 52.7566C1.25584 52.9659 1.19223 53.2033 1.19223 53.445C1.19223 53.6866 1.25584 53.924 1.37667 54.1333C1.47637 54.3403 1.6318 54.5155 1.82551 54.6392C2.01922 54.7628 2.24355 54.83 2.47334 54.8333H53.6667C53.8964 54.83 54.1208 54.7628 54.3145 54.6392C54.5082 54.5155 54.6636 54.3403 54.7633 54.1333C54.8842 53.924 54.9478 53.6866 54.9478 53.445C54.9478 53.2033 54.8842 52.9659 54.7633 52.7566L22.9367 1.16663"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                        <path
                            d="M38.15 54.8332L29.0733 39.2466C28.9651 39.0575 28.8089 38.9003 28.6204 38.791C28.4319 38.6817 28.2179 38.6241 28 38.6241C27.7821 38.6241 27.5681 38.6817 27.3796 38.791C27.1912 38.9003 27.0349 39.0575 26.9267 39.2466L17.85 54.8332"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                    </svg>
                    <h3>582</h3>
                    <p>Offchain entities</p>
                </div>
                <div class="info-card">
                    <svg width="56" height="56" viewBox="0 0 56 56" fill="none" xmlns="http://www.w3.org/2000/svg">
                        <path
                            d="M31.22 1.20862C31.3456 1.17387 31.4792 1.18218 31.5995 1.23224C31.7199 1.28229 31.82 1.37121 31.8839 1.48479C31.9478 1.59838 31.9718 1.73009 31.9521 1.85893C31.9325 1.98776 31.8702 2.1063 31.7753 2.19562C30.6619 3.17496 29.7547 4.36617 29.1065 5.6998C28.4583 7.03343 28.0822 8.48276 28 9.96329C27.9975 11.491 28.3066 13.0031 28.9084 14.4073C29.5101 15.8115 30.392 17.0782 31.5 18.13C33.2044 16.4158 34.3721 14.2419 34.86 11.8743C34.879 11.786 34.9182 11.7034 34.9745 11.6329C35.0309 11.5624 35.1028 11.5059 35.1847 11.4679C35.2665 11.4299 35.3561 11.4114 35.4463 11.4139C35.5366 11.4164 35.625 11.4398 35.7046 11.4823C38.3343 12.9559 40.5215 15.1069 42.0389 17.7116C43.5562 20.3163 44.3485 23.2798 44.3333 26.2943C44.3333 30.6262 42.6125 34.7806 39.5494 37.8437C36.4863 40.9068 32.3318 42.6276 28 42.6276C23.6681 42.6276 19.5136 40.9068 16.4505 37.8437C13.3875 34.7806 11.6666 30.6262 11.6666 26.2943C11.8055 20.5691 13.7811 15.0402 17.3018 10.5233C20.8225 6.00649 25.7019 2.74097 31.22 1.20862V1.20862Z"
                            stroke="#6366F1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        </path>
                        <path d="M1.17267 54.8613L54.837 43.1807" stroke="#6366F1" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                        </path>
                        <path d="M17.5 46.7436L1.17133 43.1946" stroke="#6366F1" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                        </path>
                        <path d="M54.8403 54.8473L38.507 51.303" stroke="#6366F1" stroke-width="2" stroke-linecap="round"
                            stroke-linejoin="round">
                        </path>
                    </svg>
                    <h3>1394</h3>
                    <p>Onchain Entities</p>
                </div>
            </div>
        </div>
        <div class="client-container" style="display: flex; opacity: 1;">
            <h3>Here from the beginning and growing together with the space</h3>
            <div class="client-container-row" data-testid="logo-line">
                <div class="one-odd">
                    <a href="https://linkpool.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Linkpool.svg')); ?>" alt="Linkpool BC" title="Linkpool BC" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="http://telosfoundation.io" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Telos.svg')); ?>" alt="Telos Foundation" title="Telos Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://1inch.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/1inch.svg')); ?>" alt="1inch Foundation" title="1inch Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://api3.org/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Mute Foundation.svg')); ?>" alt="API3 Foundation" title="API3 Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.boqpod.ch/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/BoqPod.svg')); ?>" alt="BoqPod (Hong Kong) Limited" title="BoqPod (Hong Kong) Limited" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://continuum.world/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Continuum.svg')); ?>" alt="Continuum World Ltd." title="Continuum World Ltd." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://creaticles.com/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Creaticles.svg')); ?>" alt="Creaticles" title="Creaticles" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    
                    <a href="http://fidira.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Fidira.svg')); ?>" alt="Fidira" title="Fidira" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://mute.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/API3.svg')); ?>" alt="Mute Foundation" title="Mute Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.rfox.com/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Redfox.svg')); ?>" alt="Redfox Labs Limited" title="Redfox Labs Limited" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                </div>
                <div class="two-odd">
                    <a href="https://linkpool.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Linkpool.svg')); ?>" alt="Linkpool BC" title="Linkpool BC" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="http://telosfoundation.io" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Telos.svg')); ?>" alt="Telos Foundation" title="Telos Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://1inch.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/1inch.svg')); ?>" alt="1inch Foundation" title="1inch Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://api3.org/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Mute Foundation.svg')); ?>" alt="API3 Foundation" title="API3 Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.boqpod.ch/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/BoqPod.svg')); ?>" alt="BoqPod (Hong Kong) Limited" title="BoqPod (Hong Kong) Limited" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://continuum.world/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Continuum.svg')); ?>" alt="Continuum World Ltd." title="Continuum World Ltd." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://creaticles.com/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Creaticles.svg')); ?>" alt="Creaticles" title="Creaticles" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    
                    <a href="http://fidira.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Fidira.svg')); ?>" alt="Fidira" title="Fidira" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://mute.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/API3.svg')); ?>" alt="Mute Foundation" title="Mute Foundation" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.rfox.com/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Redfox.svg')); ?>" alt="Redfox Labs Limited" title="Redfox Labs Limited" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                </div>
            </div>
            <div class="client-container-row" data-testid="logo-line">
                <div class="one-even">
                    <a href="https://cannumo.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/CANNUMO.svg')); ?>"
                            alt="CANNUMO LTD." title="CANNUMO LTD." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://aag.ventures/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/ACHIP.svg')); ?>"
                            alt="ACHIP &amp; ACHAIR GUILD VENTURES PTE. LTD" title="ACHIP &amp; ACHAIR GUILD VENTURES PTE. LTD"
                            data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://apeswap.finance/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/ApeSwap.svg')); ?>"
                            alt="ApeSwap Foundation" title="ApeSwap Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://humandao.org/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/humanDAO.svg')); ?>"
                            alt="humanDAO" title="humanDAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.brahma.fi/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/BrahmaFi.svg')); ?>"
                            alt="BrahmaFi Ltd." title="BrahmaFi Ltd." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://enrex.io/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Enrex.svg')); ?>"
                            alt="Enrex Ltd" title="Enrex Ltd" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://contango.exchange/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/CONTANGO.svg')); ?>"
                            alt="CONTANGO PROTOCOL LTD" title="CONTANGO PROTOCOL LTD" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://daoiq.money/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/DAOIQ.svg')); ?>"
                            alt="DAOIQ LTD" title="DAOIQ LTD" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="http://fluensure.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Fluensure.svg')); ?>"
                            alt="Fluensure Ltd." title="Fluensure Ltd." data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.troverse.io/" target="_blank"  rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Troverse.svg')); ?>"
                            alt="Troverse Digital Ltd." title="Troverse Digital Ltd." data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                </div>
                <div class="two-even">
                    <a href="https://cannumo.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/CANNUMO.svg')); ?>"
                            alt="CANNUMO LTD." title="CANNUMO LTD." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://aag.ventures/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/ACHIP.svg')); ?>"
                            alt="ACHIP &amp; ACHAIR GUILD VENTURES PTE. LTD" title="ACHIP &amp; ACHAIR GUILD VENTURES PTE. LTD"
                            data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://apeswap.finance/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/ApeSwap.svg')); ?>"
                            alt="ApeSwap Foundation" title="ApeSwap Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://humandao.org/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/humanDAO.svg')); ?>"
                            alt="humanDAO" title="humanDAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.brahma.fi/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/BrahmaFi.svg')); ?>"
                            alt="BrahmaFi Ltd." title="BrahmaFi Ltd." data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://enrex.io/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Enrex.svg')); ?>"
                            alt="Enrex Ltd" title="Enrex Ltd" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://contango.exchange/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/CONTANGO.svg')); ?>"
                            alt="CONTANGO PROTOCOL LTD" title="CONTANGO PROTOCOL LTD" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://daoiq.money/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/DAOIQ.svg')); ?>"
                            alt="DAOIQ LTD" title="DAOIQ LTD" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="http://fluensure.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Fluensure.svg')); ?>"
                            alt="Fluensure Ltd." title="Fluensure Ltd." data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.troverse.io/" target="_blank"  rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Troverse.svg')); ?>"
                            alt="Troverse Digital Ltd." title="Troverse Digital Ltd." data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                </div>
            </div>
            <div class="client-container-row" data-testid="logo-line">
                <div class="one-odd">
                    <a href="https://creaton.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Creation.svg')); ?>"
                            alt="Creation DAO Ltd" title="Creation DAO Ltd" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://makerdao.com/en/" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/MakerDAO.svg')); ?>"
                            alt="MakerDAO" title="MakerDAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://ethereum.org/en/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Ethereum.svg')); ?>"
                            alt="Ethereum Foundation" title="Ethereum Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://gnosis.io/" target="_blank"
                        rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Gnosis.svg')); ?>"
                            alt="Gnosis" title="Gnosis" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://status.im/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Status.svg')); ?>"
                            alt="Status" title="Status" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.klimadao.finance/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Klima.svg')); ?>"
                            alt="Klima DAO" title="Klima DAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://tezos.domains/en" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Strake.svg')); ?>"
                            alt="Strake Foundation LLC" title="Strake Foundation LLC" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.kali.gg/" target="_blank"
                        rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/AavegotchiDAO.svg')); ?>"
                            alt="The AavegotchiDAO Foundation" title="The AavegotchiDAO Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://xrd.domains/" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/RNS.svg')); ?>"
                            alt="RNS Foundation" title="RNS Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://twitter.com/SubgraphDAO" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/SubgraphDAO.svg')); ?>"
                            alt="SubgraphDAO Foundation" title="SubgraphDAO Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                </div>
                <div class="two-odd">
                    <a href="https://creaton.io/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Creation.svg')); ?>"
                            alt="Creation DAO Ltd" title="Creation DAO Ltd" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://makerdao.com/en/" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/MakerDAO.svg')); ?>"
                            alt="MakerDAO" title="MakerDAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://ethereum.org/en/" target="_blank" rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Ethereum.svg')); ?>"
                            alt="Ethereum Foundation" title="Ethereum Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://gnosis.io/" target="_blank"
                        rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/Gnosis.svg')); ?>"
                            alt="Gnosis" title="Gnosis" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://status.im/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Status.svg')); ?>"
                            alt="Status" title="Status" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.klimadao.finance/" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Klima.svg')); ?>"
                            alt="Klima DAO" title="Klima DAO" data-testid="client-logo" style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://tezos.domains/en" target="_blank" rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/Strake.svg')); ?>"
                            alt="Strake Foundation LLC" title="Strake Foundation LLC" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://www.kali.gg/" target="_blank"
                        rel="noopener noreferrer">
                        <img src="<?php echo e(asset('assets/imgs/client/AavegotchiDAO.svg')); ?>"
                            alt="The AavegotchiDAO Foundation" title="The AavegotchiDAO Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://xrd.domains/" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/RNS.svg')); ?>"
                            alt="RNS Foundation" title="RNS Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                    <a href="https://twitter.com/SubgraphDAO" target="_blank"
                        rel="noopener noreferrer">
                        <img
                            src="<?php echo e(asset('assets/imgs/client/SubgraphDAO.svg')); ?>"
                            alt="SubgraphDAO Foundation" title="SubgraphDAO Foundation" data-testid="client-logo"
                            style="margin: 1.5rem 3rem;">
                    </a>
                </div>
            </div>
        </div>   
         
    </div>

    


    
<?php $__env->stopSection(); ?>
                





<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\otonomous\resources\views/home.blade.php ENDPATH**/ ?>